export class FAQ {
  Faqid: number;
  Faqdescription: string;
  Faqanswer: string;
  }

 