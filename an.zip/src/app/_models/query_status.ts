export class Query_Status {
    Equipment_Query_Status_ID: number;
    Equipment_Query_Description: string;
    }