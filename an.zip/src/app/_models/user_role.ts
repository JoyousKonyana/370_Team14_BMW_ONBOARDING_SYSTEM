
export class User_Role {
    User_Role_ID: number;
    User_Role_Acess_Description: string;
    User_Role_Name: string;
}