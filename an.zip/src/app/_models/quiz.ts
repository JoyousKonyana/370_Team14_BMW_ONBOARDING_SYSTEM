export class Quiz {
    Quiz_ID: number;
    Lesson_Outcome_ID: string;
    
}