export class Equipment {
    Equipment_ID: number; 
    Equipment_Type_ID: string; 
    Equipment_Trade_In_Status_ID: string;  
    Equipment_Description: string; 
    Equipment_Warranty: string; 
    Equpment_Trade_In_Date: string; 
    Equipment_Brand: string;  
    Serial_Number: number; 
}