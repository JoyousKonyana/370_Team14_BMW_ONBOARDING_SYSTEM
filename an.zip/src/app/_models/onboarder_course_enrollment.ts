export class Onboarder_Course_Enrollment {
    Onboarder_ID: number;
    Course_ID: string;
    Enrollment_Date: string;
    Tokens_Total: string;
    Completion_Date: string;
    Onboarder_Progress: string;
  }