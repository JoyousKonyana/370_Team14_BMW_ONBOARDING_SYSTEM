export class Learning_Outcome {
    Learning_Outcome_ID: number;
    Lesson_ID: number;
    Lesson_Outcome_Description: string;
  }