export class Equipment_Type {
    Equipment_Type_ID: number;
    Equipment_Type_Description: string;
    }
  
   