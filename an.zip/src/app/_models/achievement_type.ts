export class Achievment_Type {
    Achievment_Type_ID: number;
    Badge_ID: string;
    Achievment_Type_Description: string;
    }
  
   