export class Option {
    Option_ID: number;
    Option_Detail: string;
}