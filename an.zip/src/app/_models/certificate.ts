

export class Certificate {
    Certificate_ID: number;
    Lesson_Completion_ID: string;
    Certificate_Description: string;
    Certificate_Date_Generated: string;
    Certificate_Type_ID: string
  }