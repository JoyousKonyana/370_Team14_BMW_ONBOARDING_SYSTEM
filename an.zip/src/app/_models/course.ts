export class Course {
    Course_ID: number;
    Course_Description: string;
    Due_Date: string;
    Message: string;
  }