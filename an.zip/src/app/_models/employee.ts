export class Employee {
    Employee_ID: number;
    Department_ID: number;
    first_name: string; 
    Middle_Name: string; 
    Last_Name: string;  
    Title: string; 
    Gender_ID: string; 
    ID_Number: string; 
    Contact_Number: string; 
    Job_Title: string; 
    Address_ID: number; 
  }