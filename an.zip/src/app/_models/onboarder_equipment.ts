export class Onboarder_Equipment {
    Equipment_ID: string; 
    Onboarder_ID: string; 
    Equipment_Check_Out_Date: string;  
    Equipment_Check_Out_Description: string; 
    Equipment_Check_In_Date: string;  
    Equipment_Check_In_Description: string; 
  }