export class Lesson_Content {
    Lesson_Content_ID: number;
    Lesson_Content_Type_ID: number;
    Lesson_ID: number;
    Active_Status_ID: number;
    Lesson_Content_Description: string
  }