//Landing Pages
export * from './ss_administrator.component';

//Administrator
export * from './onboarder.component';
export * from './register_employee.component';
export * from './assign_equipment.component';
export * from './crud_faq.component';
export * from './import_employee.component';
export * from './crud_employee.component';