import { EditCourseComponent } from './Course/3.3 Edit course/edit-course/edit-course.component';
import { AssignedEquipmentComponent } from './Admin/2.1Register Employee/2.5 Assign Equipment/assigned-equipment/assigned-equipment.component';
import { ViewOnboardersComponent } from './Admin/2.1Register Employee/2.2 VIew onboarder/2.2 View onboarder/view-onboarders/view-onboarders.component';
import { ViewArchivedLessonContentComponent, archivedLessonContent } from './Course/3.21 VIew Archived lesson content/view-archived-lesson-content/view-archived-lesson-content.component';
import { ViewLessonOutcomeComponent } from './Course/view-lesson-outcome/view-lesson-outcome.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdministratorlandingComponent } from './administratorlanding/administratorlanding.component';
import { CreateCourseComponent } from './Course/3.1 Create course/create-course/create-course.component';
import { CreateQuestionComponent } from './Course/3.9 Create question/create-question/create-question.component';
import { DeleteCourseConfirmationComponent } from './Course/3.4 Delete Course/delete-course-confirmation/delete-course-confirmation.component';
import { LessonOutcomeComponent } from './Course/3.18 Create lesson outcome/lesson-outcome/lesson-outcome.component';
import { SetQuizComponent } from './Course/3.6 Set new quiz/set-quiz/set-quiz.component';
import { UpdateCourseComponent } from './Course/3.3 Edit course/update-course/update-course.component';
import { ViewCoursesAdminComponent } from './Course/3.2 View course/view-courses-admin/view-courses-admin.component';
import { ViewQuestionBankComponent } from './Course/3.8 View Question Bank/view-question-bank/view-question-bank.component';
import { EditLessonOutcomeComponent } from './Course/3.19 Update lesson outcome/edit-lesson-outcome/edit-lesson-outcome.component';
import { ArchivelessonContentComponent } from './Course/3.22 Archive lesson content/archivelesson-content/archivelesson-content.component';
import { EquipmentLandingPageComponent } from './equipment/equipment-landing-page/equipment landing page/equipment-landing-page.component';
import { RegisteronBoarderComponent } from './Admin/2.1Register Employee/2.1  Register Employee/registeron-boarder/registeron-boarder.component';
import { EditOnboarderComponent } from './Admin/2.1Register Employee/2.3 Edit onboarder/edit-onboarder/edit-onboarder.component';
import { RegisterEquipmentComponent } from './equipment/4.1 Register Equipment/register-equipment/register-equipment.component';
import { ViewEquipmentComponent } from './equipment/view-equipment/view-equipment.component';
import { ViewTradeInStatusComponent } from './equipment/4.13 View Trade in status/view-trade-in-status/view-trade-in-status.component';
import { SendEquipmentdueForTradeInComponent } from './equipment/4.12 Send equipment due for trade in/send-equipmentdue-for-trade-in/send-equipmentdue-for-trade-in.component';
import { ViewpagesComponent } from './equipment/viewpages/viewpages.component';
import { ViewQueryStatusComponent } from './equipment/4.9 VIew my query/view-query-status/view-query-status.component';
import { UpdateEquipmentComponent } from './equipment/4.5 Update Equipment/update-equipment/update-equipment.component';
import { ViewEquipmentUpdateComponent } from './equipment/4.5 Update Equipment/view-equipment-update/view-equipment-update.component';
import { DeleteEquipmentComponent } from './equipment/4.6 Delete equipment/delete-equipment/delete-equipment.component';
import { SearchEquipmentComponent } from './equipment/4.3 Search equipment/search-equipment/search-equipment.component';
import { ViewAssignedEquipmentComponent } from './equipment/4.4 VIew Assigned equipment/view-assigned-equipment/view-assigned-equipment.component';
import { SearchQueryStatusComponent } from './equipment/4.11 Search Query Status/search-query-status/search-query-status.component';
import { ViewQuestionBankQuestionsComponent } from './Course/3.10  Delete question/view-question-bank-questions/view-question-bank-questions.component';
import { ViewAchivementTypesComponent } from './Course/view-achivement-types/view-achivement-types.component';
import { GenerateCourseProgressComponent } from './Course/3.13 Generate progress report/Generate course progress/generate-course-progress/generate-course-progress.component';
import { AdminLanding2Component } from './Course/admin-landing2/admin-landing2.component';
import { ReportScreenComponent } from './Course/3.13 Generate progress report/report-screen/report-screen.component';
import { ViewOnboarderComponent } from './Admin/2.1Register Employee/2.2 VIew onboarder/VIew onbaorder full information/view-onboarder/view-onboarder.component';
import { Editonboarder2Component } from './Admin/2.1Register Employee/2.3 Edit onboarder/editonboarder2/editonboarder2.component';
import { OnboarderProgressReportComponent } from './Course/3.13 Generate progress report/onboarder-progress-report/onboarder-progress-report.component';

const routes: Routes = [
  { path: 'Adminpage', component: AdministratorlandingComponent},
  {path: 'createCourse', component: CreateCourseComponent},
  {path: 'createQuestion', component: CreateQuestionComponent},
  {path: 'viewCourseA', component: ViewCoursesAdminComponent},
  {path: 'updateCourse', component: EditCourseComponent},
  {path: 'viewquestionBank', component: ViewQuestionBankComponent},
  {path: 'setQuiz', component: SetQuizComponent},
  {path:'createLessonOutcome', component: LessonOutcomeComponent},
  {path: 'viewlessonoutcomeAdmin', component: ViewLessonOutcomeComponent},
  {path:'editlessonoutcome', component: EditLessonOutcomeComponent},
  {path:'viewArchivedlessoncontent', component: ViewArchivedLessonContentComponent},
  {path: 'ArchiveLessoncontent', component: ArchivelessonContentComponent},
  {path: "EquipmenLandingAdmin", component: EquipmentLandingPageComponent},
  {path: 'registerOnboarder', component:RegisteronBoarderComponent},
  {path: 'editOnborder', component: EditOnboarderComponent},
  {path: 'viewonboarders', component:ViewOnboardersComponent},
  {path: 'registerEquipment', component: RegisterEquipmentComponent},
  {path: 'viewEquipment', component: ViewEquipmentComponent},
  {path: 'viewTradeInStatus', component: ViewTradeInStatusComponent},
  {path: 'sendEquipmentQuery', component: SendEquipmentdueForTradeInComponent},
  {path: 'viewpages', component: ViewpagesComponent},
  {path: 'viewQueryStatus', component: ViewQueryStatusComponent},
  {path: 'updateEquipment', component: UpdateEquipmentComponent},
  {path: 'viewUpdateEquipment', component: ViewEquipmentUpdateComponent},
  {path: 'deleteEquipment', component: DeleteEquipmentComponent},
  {path: 'searchEquipment', component: SearchEquipmentComponent},
  {path: 'viewAssigedEquipment', component:ViewAssignedEquipmentComponent},
  {path: 'searchqueryStatus', component: SearchQueryStatusComponent},
  {path: 'viewQuestionBankQuestions', component: ViewQuestionBankQuestionsComponent},
  {path: 'viewAchievementType', component: ViewAchivementTypesComponent},
  {path: 'generateCourseProgressReport', component: GenerateCourseProgressComponent},
  {path: 'viewadminLAnding', component: AdminLanding2Component},
  {path: 'reportsscreen', component:ReportScreenComponent},
  {path: 'viewonboarder', component:ViewOnboarderComponent},
  {path:'editonbaorder2', component:Editonboarder2Component},
  {path:'assigendEquipment', component:AssignedEquipmentComponent},
  {path:'onboarderProgressreport', component:OnboarderProgressReportComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
