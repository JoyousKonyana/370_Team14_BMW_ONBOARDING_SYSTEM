import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletelesson-content-unsuccessfull',
  templateUrl: './deletelesson-content-unsuccessfull.component.html',
  styleUrls: ['./deletelesson-content-unsuccessfull.component.css']
})
export class DeletelessonContentUnsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
