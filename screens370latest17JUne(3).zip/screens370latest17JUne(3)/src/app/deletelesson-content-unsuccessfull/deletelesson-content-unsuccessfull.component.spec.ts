import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletelessonContentUnsuccessfullComponent } from './deletelesson-content-unsuccessfull.component';

describe('DeletelessonContentUnsuccessfullComponent', () => {
  let component: DeletelessonContentUnsuccessfullComponent;
  let fixture: ComponentFixture<DeletelessonContentUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeletelessonContentUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletelessonContentUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
