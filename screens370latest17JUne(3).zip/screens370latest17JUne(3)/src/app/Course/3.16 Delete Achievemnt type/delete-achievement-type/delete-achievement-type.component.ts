import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-achievement-type',
  templateUrl: './delete-achievement-type.component.html',
  styleUrls: ['./delete-achievement-type.component.css']
})
export class DeleteAchievementTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
