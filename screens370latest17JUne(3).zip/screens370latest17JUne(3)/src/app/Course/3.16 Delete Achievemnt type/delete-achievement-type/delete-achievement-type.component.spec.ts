import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteAchievementTypeComponent } from './delete-achievement-type.component';

describe('DeleteAchievementTypeComponent', () => {
  let component: DeleteAchievementTypeComponent;
  let fixture: ComponentFixture<DeleteAchievementTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteAchievementTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteAchievementTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
