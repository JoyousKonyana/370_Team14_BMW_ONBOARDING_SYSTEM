import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achievement-type-deletion-successfull',
  templateUrl: './achievement-type-deletion-successfull.component.html',
  styleUrls: ['./achievement-type-deletion-successfull.component.css']
})
export class AchievementTypeDeletionSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
