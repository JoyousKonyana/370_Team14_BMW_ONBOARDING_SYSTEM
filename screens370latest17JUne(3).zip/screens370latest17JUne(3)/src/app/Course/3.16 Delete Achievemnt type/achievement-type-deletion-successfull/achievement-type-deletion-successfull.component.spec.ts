import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchievementTypeDeletionSuccessfullComponent } from './achievement-type-deletion-successfull.component';

describe('AchievementTypeDeletionSuccessfullComponent', () => {
  let component: AchievementTypeDeletionSuccessfullComponent;
  let fixture: ComponentFixture<AchievementTypeDeletionSuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AchievementTypeDeletionSuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AchievementTypeDeletionSuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
