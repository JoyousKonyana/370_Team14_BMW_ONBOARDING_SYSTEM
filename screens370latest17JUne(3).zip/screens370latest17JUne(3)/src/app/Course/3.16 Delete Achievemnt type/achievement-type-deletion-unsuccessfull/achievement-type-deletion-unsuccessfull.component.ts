import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achievement-type-deletion-unsuccessfull',
  templateUrl: './achievement-type-deletion-unsuccessfull.component.html',
  styleUrls: ['./achievement-type-deletion-unsuccessfull.component.css']
})
export class AchievementTypeDeletionUnsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
