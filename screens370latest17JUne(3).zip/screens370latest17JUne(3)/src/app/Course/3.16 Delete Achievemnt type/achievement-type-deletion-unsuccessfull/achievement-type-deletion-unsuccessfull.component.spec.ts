import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchievementTypeDeletionUnsuccessfullComponent } from './achievement-type-deletion-unsuccessfull.component';

describe('AchievementTypeDeletionUnsuccessfullComponent', () => {
  let component: AchievementTypeDeletionUnsuccessfullComponent;
  let fixture: ComponentFixture<AchievementTypeDeletionUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AchievementTypeDeletionUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AchievementTypeDeletionUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
