import { EditCourseComponent } from './../../3.3 Edit course/edit-course/edit-course.component';
import { ViewCourseErrorComponent } from '../view-course-error/view-course-error.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteCourseConfirmationComponent } from '../../3.4 Delete Course/delete-course-confirmation/delete-course-confirmation.component';
import { CourseDeletionSuccessfulComponent } from '../../3.4 Delete Course/course-deletion-successful/course-deletion-successful.component';
import { DeleteCourseUnsuccessfullComponent } from '../../3.4 Delete Course/delete-course-unsuccessfull/delete-course-unsuccessfull.component';
export interface PeriodicElement {
  name: string;
  position: number;
  description: string;
  Duration: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'IT Hub Onboarding', description: 'This Program is an introduction to everything an employee ', Duration: '2 Weeks'},
  {position: 2, name: 'Remote working productivity', description: 'Covid Prep', Duration: '1 Weeks'},
];
@Component({
  selector: 'app-view-courses-admin',
  templateUrl: './view-courses-admin.component.html',
  styleUrls: ['./view-courses-admin.component.css']
})
export class ViewCoursesAdminComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {

    // opendialogCourseError
    // this.openDialogViewCourseError();

    // open delete confirmation

    // this.openDialogDeleteCourseConfirmation();

    // //open course deletion succesfull
    // this.openDialogDeleteCourseSuccessfull();

    // delete course
    this.openDialogDeleteCourseUnSuccessfull();
  }
  displayedColumns: string[] = ['#', 'Course Name', 'Course Description', 'Duration',
'Actions'];
  dataSource = ELEMENT_DATA;

  openDialogViewCourseError() {
    const dialogRef = this.dialog.open(ViewCourseErrorComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogDeleteCourseConfirmation() {
    const dialogRef = this.dialog.open(DeleteCourseConfirmationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });
  }

  openDialogDeleteCourseSuccessfull() {
    const dialogRef = this.dialog.open(CourseDeletionSuccessfulComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });
  }

  openDialogDeleteCourseUnSuccessfull() {
    const dialogRef = this.dialog.open(DeleteCourseUnsuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });
  }


  openDialogEditCourse() {
    const dialogRef = this.dialog.open(EditCourseComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });
  }
}
