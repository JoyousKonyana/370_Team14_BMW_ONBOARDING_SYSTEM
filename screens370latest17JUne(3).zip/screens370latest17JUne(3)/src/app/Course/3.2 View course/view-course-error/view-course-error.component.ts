import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-course-error',
  templateUrl: './view-course-error.component.html',
  styleUrls: ['./view-course-error.component.css']
})
export class ViewCourseErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
