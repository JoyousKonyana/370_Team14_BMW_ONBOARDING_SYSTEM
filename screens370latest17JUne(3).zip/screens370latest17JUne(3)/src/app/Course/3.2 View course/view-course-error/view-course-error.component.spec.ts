import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCourseErrorComponent } from './view-course-error.component';

describe('ViewCourseErrorComponent', () => {
  let component: ViewCourseErrorComponent;
  let fixture: ComponentFixture<ViewCourseErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewCourseErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCourseErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
