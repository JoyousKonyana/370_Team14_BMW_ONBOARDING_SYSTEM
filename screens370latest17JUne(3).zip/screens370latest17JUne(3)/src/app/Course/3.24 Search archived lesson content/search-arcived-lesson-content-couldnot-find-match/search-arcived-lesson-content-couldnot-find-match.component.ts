import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-arcived-lesson-content-couldnot-find-match',
  templateUrl: './search-arcived-lesson-content-couldnot-find-match.component.html',
  styleUrls: ['./search-arcived-lesson-content-couldnot-find-match.component.css']
})
export class SearchARcivedLessonContentCouldnotFindMatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
