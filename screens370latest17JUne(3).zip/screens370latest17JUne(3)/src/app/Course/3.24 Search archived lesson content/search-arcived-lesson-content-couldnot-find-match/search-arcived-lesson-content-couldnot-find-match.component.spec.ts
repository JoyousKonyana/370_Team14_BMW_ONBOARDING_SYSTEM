import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchARcivedLessonContentCouldnotFindMatchComponent } from './search-arcived-lesson-content-couldnot-find-match.component';

describe('SearchARcivedLessonContentCouldnotFindMatchComponent', () => {
  let component: SearchARcivedLessonContentCouldnotFindMatchComponent;
  let fixture: ComponentFixture<SearchARcivedLessonContentCouldnotFindMatchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchARcivedLessonContentCouldnotFindMatchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchARcivedLessonContentCouldnotFindMatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
