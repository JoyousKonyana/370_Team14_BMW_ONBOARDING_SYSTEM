import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-creation-failure',
  templateUrl: './question-creation-failure.component.html',
  styleUrls: ['./question-creation-failure.component.css']
})
export class QuestionCreationFailureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
