import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionCreationFailureComponent } from './question-creation-failure.component';

describe('QuestionCreationFailureComponent', () => {
  let component: QuestionCreationFailureComponent;
  let fixture: ComponentFixture<QuestionCreationFailureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestionCreationFailureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionCreationFailureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
