import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-question-creation',
  templateUrl: './cancel-question-creation.component.html',
  styleUrls: ['./cancel-question-creation.component.css']
})
export class CancelQuestionCreationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
