import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelQuestionCreationComponent } from './cancel-question-creation.component';

describe('CancelQuestionCreationComponent', () => {
  let component: CancelQuestionCreationComponent;
  let fixture: ComponentFixture<CancelQuestionCreationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CancelQuestionCreationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelQuestionCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
