import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CancelQuestionCreationComponent } from '../cancel-question-creation/cancel-question-creation.component';
import { ConfirmCreateQuestionComponent } from '../confirm-create-question/confirm-create-question.component';
import { QuestionCreationFailureComponent } from '../question-creation-failure/question-creation-failure.component';
import { QuestionCreationSuccessComponent } from '../question-creation-success/question-creation-success.component';
@Component({
  selector: 'app-create-question',
  templateUrl: './create-question.component.html',
  styleUrls: ['./create-question.component.css']
})
export class CreateQuestionComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogConfirm() {
    const dialogRef = this.dialog.open(ConfirmCreateQuestionComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogSuccess() {
    const dialogRef = this.dialog.open(QuestionCreationSuccessComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }


  openDialogFailure() {
    const dialogRef = this.dialog.open(QuestionCreationFailureComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogExitchnages() {
    const dialogRef = this.dialog.open(CancelQuestionCreationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }


}
