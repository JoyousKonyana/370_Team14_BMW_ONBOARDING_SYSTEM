import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmCreateQuestionComponent } from './confirm-create-question.component';

describe('ConfirmCreateQuestionComponent', () => {
  let component: ConfirmCreateQuestionComponent;
  let fixture: ComponentFixture<ConfirmCreateQuestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmCreateQuestionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmCreateQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
