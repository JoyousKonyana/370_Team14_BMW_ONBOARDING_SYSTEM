import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-create-question',
  templateUrl: './confirm-create-question.component.html',
  styleUrls: ['./confirm-create-question.component.css']
})
export class ConfirmCreateQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
