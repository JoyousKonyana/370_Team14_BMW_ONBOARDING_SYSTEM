import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-creation-success',
  templateUrl: './question-creation-success.component.html',
  styleUrls: ['./question-creation-success.component.css']
})
export class QuestionCreationSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
