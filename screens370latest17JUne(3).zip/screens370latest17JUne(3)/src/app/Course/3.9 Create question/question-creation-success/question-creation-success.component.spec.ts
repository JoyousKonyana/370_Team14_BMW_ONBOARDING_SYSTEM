import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionCreationSuccessComponent } from './question-creation-success.component';

describe('QuestionCreationSuccessComponent', () => {
  let component: QuestionCreationSuccessComponent;
  let fixture: ComponentFixture<QuestionCreationSuccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestionCreationSuccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionCreationSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
