import { UpdateQuetsionBankComponent } from './../../3.7 Update question Bank/update-quetsion-bank/update-quetsion-bank.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ViewQuestionBankErrorComponent } from '../view-question-bank-error/view-question-bank-error.component';

export interface Question_Bank {
  position: number;
  category: string;
  compulsory:string;
  numberOfQuestion:number;
}

const ELEMENT_DATA: Question_Bank[] = [
  // {position: 1, category:'Sexual harassment', compulsory: 'Yes ',numberOfQuestion: 301},
  // {position: 2, category:'Our Culture', compulsory: 'No ',numberOfQuestion: 124},

];
@Component({
  selector: 'app-view-question-bank',
  templateUrl: './view-question-bank.component.html',
  styleUrls: ['./view-question-bank.component.css']
})
export class ViewQuestionBankComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.openDialogViewquestionBankError();
  }

  displayedColumns: string[] = ['#', 'Question Bank Category', 'Compulsory Pass', 'Number Of Questions',
  'Actions'];
    dataSource = ELEMENT_DATA;

    openDialogViewquestionBankError() {
      const dialogRef = this.dialog.open(ViewQuestionBankErrorComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogEditQuestionBank() {
      const dialogRef = this.dialog.open(UpdateQuetsionBankComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }
}
