import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-question-bank-error',
  templateUrl: './view-question-bank-error.component.html',
  styleUrls: ['./view-question-bank-error.component.css']
})
export class ViewQuestionBankErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
