import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewQuestionBankErrorComponent } from './view-question-bank-error.component';

describe('ViewQuestionBankErrorComponent', () => {
  let component: ViewQuestionBankErrorComponent;
  let fixture: ComponentFixture<ViewQuestionBankErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewQuestionBankErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewQuestionBankErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
