import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateQuetsionBankComponent } from './update-quetsion-bank.component';

describe('UpdateQuetsionBankComponent', () => {
  let component: UpdateQuetsionBankComponent;
  let fixture: ComponentFixture<UpdateQuetsionBankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateQuetsionBankComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateQuetsionBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
