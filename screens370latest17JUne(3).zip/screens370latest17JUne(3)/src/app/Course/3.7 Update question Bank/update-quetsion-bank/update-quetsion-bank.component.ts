import { UpdateQuestionBankErrorComponent } from './../update-question-bank-error/update-question-bank-error.component';
import { UpdateQuestionBankConfirmComponent } from './../update-question-bank-confirm/update-question-bank-confirm.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { QuestionBAnkSuccessfullyUpdatedComponent } from '../question-bank-successfully-updated/question-bank-successfully-updated.component';
@Component({
  selector: 'app-update-quetsion-bank',
  templateUrl: './update-quetsion-bank.component.html',
  styleUrls: ['./update-quetsion-bank.component.css']
})
export class UpdateQuetsionBankComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogUpdateQuestionBAnk() {
    const dialogRef = this.dialog.open(UpdateQuestionBankConfirmComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }


  openDialogUpdateQuestionBAnkError() {
    const dialogRef = this.dialog.open(UpdateQuestionBankErrorComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogUpdateQuestionBAnksuccessfull() {
    const dialogRef = this.dialog.open(QuestionBAnkSuccessfullyUpdatedComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

}
