import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateQuestionBankErrorComponent } from './update-question-bank-error.component';

describe('UpdateQuestionBankErrorComponent', () => {
  let component: UpdateQuestionBankErrorComponent;
  let fixture: ComponentFixture<UpdateQuestionBankErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateQuestionBankErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateQuestionBankErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
