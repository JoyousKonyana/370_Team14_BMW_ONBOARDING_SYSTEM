import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-question-bank-error',
  templateUrl: './update-question-bank-error.component.html',
  styleUrls: ['./update-question-bank-error.component.css']
})
export class UpdateQuestionBankErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
