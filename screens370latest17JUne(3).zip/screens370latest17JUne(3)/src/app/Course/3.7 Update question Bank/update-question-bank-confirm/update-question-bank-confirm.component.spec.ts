import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateQuestionBankConfirmComponent } from './update-question-bank-confirm.component';

describe('UpdateQuestionBankConfirmComponent', () => {
  let component: UpdateQuestionBankConfirmComponent;
  let fixture: ComponentFixture<UpdateQuestionBankConfirmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateQuestionBankConfirmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateQuestionBankConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
