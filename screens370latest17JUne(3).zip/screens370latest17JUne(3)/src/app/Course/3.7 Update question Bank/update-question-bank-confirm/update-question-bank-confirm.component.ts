import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-question-bank-confirm',
  templateUrl: './update-question-bank-confirm.component.html',
  styleUrls: ['./update-question-bank-confirm.component.css']
})
export class UpdateQuestionBankConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
