import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-bank-successfully-updated',
  templateUrl: './question-bank-successfully-updated.component.html',
  styleUrls: ['./question-bank-successfully-updated.component.css']
})
export class QuestionBAnkSuccessfullyUpdatedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
