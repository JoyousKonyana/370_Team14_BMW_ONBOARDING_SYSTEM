import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionBAnkSuccessfullyUpdatedComponent } from './question-bank-successfully-updated.component';

describe('QuestionBAnkSuccessfullyUpdatedComponent', () => {
  let component: QuestionBAnkSuccessfullyUpdatedComponent;
  let fixture: ComponentFixture<QuestionBAnkSuccessfullyUpdatedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestionBAnkSuccessfullyUpdatedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionBAnkSuccessfullyUpdatedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
