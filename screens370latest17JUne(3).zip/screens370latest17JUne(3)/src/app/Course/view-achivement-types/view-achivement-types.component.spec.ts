import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAchivementTypesComponent } from './view-achivement-types.component';

describe('ViewAchivementTypesComponent', () => {
  let component: ViewAchivementTypesComponent;
  let fixture: ComponentFixture<ViewAchivementTypesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAchivementTypesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAchivementTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
