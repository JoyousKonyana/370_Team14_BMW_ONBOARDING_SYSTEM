import { CreateAchievementTypeComponent } from './../3.14 Create Achievement type/create-achievement-type/create-achievement-type.component';
import { ViewAchievementTypeErrorComponent } from './../view-achievement-type-error/view-achievement-type-error.component';
import { AchievementTypeDeletionSuccessfullComponent } from './../3.16 Delete Achievemnt type/achievement-type-deletion-successfull/achievement-type-deletion-successfull.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EditLessonOutcomeComponent } from 'src/app/Course/3.19 Update lesson outcome/edit-lesson-outcome/edit-lesson-outcome.component';
import { DeleteAchievementTypeComponent } from '../3.16 Delete Achievemnt type/delete-achievement-type/delete-achievement-type.component';
import { AchievementTypeDeletionUnsuccessfullComponent } from '../3.16 Delete Achievemnt type/achievement-type-deletion-unsuccessfull/achievement-type-deletion-unsuccessfull.component';
import { SearchAchievemenTypeCouldNotFindMatchComponent } from '../SEarch achievement type/search-achievemen-type-could-not-find-match/search-achievemen-type-could-not-find-match.component';
import { UpdateAchievementTypeComponent } from '../3.15 Update Achievement type/update-achievement-type/update-achievement-type.component';

export interface AchievementTYpe {
 achievementType: string;
 achievementTypeID: string;


}

const ELEMENT_DATA: AchievementTYpe[] = [
 {achievementType: 'You have achieved a Distinction', achievementTypeID: '1'},
 {achievementType: 'You have met the minimum requirement for passing', achievementTypeID: '2'},
];
@Component({
  selector: 'app-view-achivement-types',
  templateUrl: './view-achivement-types.component.html',
  styleUrls: ['./view-achivement-types.component.css']
})
export class ViewAchivementTypesComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.openDialogViewAchievementTypeError();
  }

  displayedColumns: string[] = ['#', 'Achievement Type',
  'Actions'];
    dataSource = ELEMENT_DATA;

    openDialogDelelteAchievementType() {
      const dialogRef = this.dialog.open(DeleteAchievementTypeComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }
    

    openDialogDelelteAchievementTypesuccessfull() {
      const dialogRef = this.dialog.open(AchievementTypeDeletionSuccessfullComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogDelelteAchievementTypeunsuccessfull() {
      const dialogRef = this.dialog.open(AchievementTypeDeletionUnsuccessfullComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogSEarchAchievementTypelesson() {
      const dialogRef = this.dialog.open(SearchAchievemenTypeCouldNotFindMatchComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }
    openDialogViewAchievementTypeError() {
      const dialogRef = this.dialog.open(ViewAchievementTypeErrorComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogCreateAchievementType() {
      const dialogRef = this.dialog.open(CreateAchievementTypeComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogUpdateAchievementType() {
      const dialogRef = this.dialog.open(UpdateAchievementTypeComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogConfirmAchievementTypeDelete() {
      const dialogRef = this.dialog.open(DeleteAchievementTypeComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }
}
