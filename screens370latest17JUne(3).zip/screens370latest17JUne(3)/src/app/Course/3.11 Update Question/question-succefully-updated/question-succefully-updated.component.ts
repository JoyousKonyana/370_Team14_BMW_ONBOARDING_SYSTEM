import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-succefully-updated',
  templateUrl: './question-succefully-updated.component.html',
  styleUrls: ['./question-succefully-updated.component.css']
})
export class QuestionSuccefullyUpdatedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
