import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionSuccefullyUpdatedComponent } from './question-succefully-updated.component';

describe('QuestionSuccefullyUpdatedComponent', () => {
  let component: QuestionSuccefullyUpdatedComponent;
  let fixture: ComponentFixture<QuestionSuccefullyUpdatedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestionSuccefullyUpdatedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionSuccefullyUpdatedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
