import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmUpdateQuestionComponent } from '../confirm-update-question/confirm-update-question.component';
import { QuestionSuccefullyUpdatedComponent } from '../question-succefully-updated/question-succefully-updated.component';
import { UpdateQuestionErrorComponent } from '../update-question-error/update-question-error.component';
@Component({
  selector: 'app-update-question',
  templateUrl: './update-question.component.html',
  styleUrls: ['./update-question.component.css']
})
export class UpdateQuestionComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }
  openDialogConfirmUpdateQuestion() {
    const dialogRef = this.dialog.open(ConfirmUpdateQuestionComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });
  }

  openDialogConfirmUpdateQuestionError() {
    const dialogRef = this.dialog.open(UpdateQuestionErrorComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });
  }

  openDialogConfirmUpdateQuestionSuccessfull() {
    const dialogRef = this.dialog.open(QuestionSuccefullyUpdatedComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });
  }

}
