import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-update-question',
  templateUrl: './confirm-update-question.component.html',
  styleUrls: ['./confirm-update-question.component.css']
})
export class ConfirmUpdateQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
