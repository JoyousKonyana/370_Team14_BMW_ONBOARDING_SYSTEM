import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmUpdateQuestionComponent } from './confirm-update-question.component';

describe('ConfirmUpdateQuestionComponent', () => {
  let component: ConfirmUpdateQuestionComponent;
  let fixture: ComponentFixture<ConfirmUpdateQuestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmUpdateQuestionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmUpdateQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
