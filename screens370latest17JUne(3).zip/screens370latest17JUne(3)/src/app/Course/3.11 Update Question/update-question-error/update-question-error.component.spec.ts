import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateQuestionErrorComponent } from './update-question-error.component';

describe('UpdateQuestionErrorComponent', () => {
  let component: UpdateQuestionErrorComponent;
  let fixture: ComponentFixture<UpdateQuestionErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateQuestionErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateQuestionErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
