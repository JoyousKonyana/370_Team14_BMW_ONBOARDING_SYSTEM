import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-question-error',
  templateUrl: './update-question-error.component.html',
  styleUrls: ['./update-question-error.component.css']
})
export class UpdateQuestionErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
