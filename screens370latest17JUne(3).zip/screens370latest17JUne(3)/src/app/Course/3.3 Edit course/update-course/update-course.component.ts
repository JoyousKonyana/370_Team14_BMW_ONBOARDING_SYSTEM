import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CourseUpdateFailureComponent } from '../course-update-failure/course-update-failure.component';
import { CourseUpdateSuccessfullComponent } from '../course-update-successfull/course-update-successfull.component';
@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogCourseUpdateSuccessful() {
    const dialogRef = this.dialog.open(CourseUpdateSuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogCourseUpdateUSuccessful() {
    const dialogRef = this.dialog.open(CourseUpdateFailureComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });
  }
}
