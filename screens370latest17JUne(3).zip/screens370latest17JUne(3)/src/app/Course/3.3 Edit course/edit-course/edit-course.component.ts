import { CourseUpdateFailureComponent } from './../course-update-failure/course-update-failure.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmUpdateCourseComponent } from '../confirm-update-course/confirm-update-course.component';
import { CourseUpdateSuccessfullComponent } from '../course-update-successfull/course-update-successfull.component';
@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.css']
})
export class EditCourseComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogConfirmCourseUpdate() {
    const dialogRef = this.dialog.open(ConfirmUpdateCourseComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogCourseUpdateUNsuccessfull() {
    const dialogRef = this.dialog.open(CourseUpdateSuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

}
