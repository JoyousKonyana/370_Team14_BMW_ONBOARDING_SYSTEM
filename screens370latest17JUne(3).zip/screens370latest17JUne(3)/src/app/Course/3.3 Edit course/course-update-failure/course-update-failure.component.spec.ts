import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseUpdateFailureComponent } from './course-update-failure.component';

describe('CourseUpdateFailureComponent', () => {
  let component: CourseUpdateFailureComponent;
  let fixture: ComponentFixture<CourseUpdateFailureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseUpdateFailureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseUpdateFailureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
