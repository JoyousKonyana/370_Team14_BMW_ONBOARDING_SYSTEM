import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-update-failure',
  templateUrl: './course-update-failure.component.html',
  styleUrls: ['./course-update-failure.component.css']
})
export class CourseUpdateFailureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
