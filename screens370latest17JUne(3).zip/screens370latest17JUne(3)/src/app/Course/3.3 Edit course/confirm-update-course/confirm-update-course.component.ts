import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-update-course',
  templateUrl: './confirm-update-course.component.html',
  styleUrls: ['./confirm-update-course.component.css']
})
export class ConfirmUpdateCourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
