import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmUpdateCourseComponent } from './confirm-update-course.component';

describe('ConfirmUpdateCourseComponent', () => {
  let component: ConfirmUpdateCourseComponent;
  let fixture: ComponentFixture<ConfirmUpdateCourseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmUpdateCourseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmUpdateCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
