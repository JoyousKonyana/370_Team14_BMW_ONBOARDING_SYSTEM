import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseUpdateSuccessfullComponent } from './course-update-successfull.component';

describe('CourseUpdateSuccessfullComponent', () => {
  let component: CourseUpdateSuccessfullComponent;
  let fixture: ComponentFixture<CourseUpdateSuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseUpdateSuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseUpdateSuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
