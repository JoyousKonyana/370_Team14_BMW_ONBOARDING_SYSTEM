import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-update-successfull',
  templateUrl: './course-update-successfull.component.html',
  styleUrls: ['./course-update-successfull.component.css']
})
export class CourseUpdateSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
