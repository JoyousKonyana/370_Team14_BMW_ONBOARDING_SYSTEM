import { Component, OnInit } from '@angular/core';
import { SetQuizConfimationComponent } from '../set-quiz-confimation/set-quiz-confimation.component';
import { MatDialog } from '@angular/material/dialog';
import { SetQuizUnsuccessfulComponent } from '../set-quiz-unsuccessful/set-quiz-unsuccessful.component';
import { SetQuizSuccessfulComponent } from '../set-quiz-successful/set-quiz-successful.component';
@Component({
  selector: 'app-set-quiz',
  templateUrl: './set-quiz.component.html',
  styleUrls: ['./set-quiz.component.css']
})
export class SetQuizComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }


  openDialogQuizConfirmation() {
    const dialogRef = this.dialog.open(SetQuizConfimationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogQuizUnsuccesssfull() {
    const dialogRef = this.dialog.open(SetQuizUnsuccessfulComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }
  openDialogQuizsuccesssfull() {
    const dialogRef = this.dialog.open(SetQuizSuccessfulComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }
}
