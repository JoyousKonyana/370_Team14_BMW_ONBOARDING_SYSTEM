import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SetQuizSuccessfulComponent } from './set-quiz-successful.component';

describe('SetQuizSuccessfulComponent', () => {
  let component: SetQuizSuccessfulComponent;
  let fixture: ComponentFixture<SetQuizSuccessfulComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SetQuizSuccessfulComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SetQuizSuccessfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
