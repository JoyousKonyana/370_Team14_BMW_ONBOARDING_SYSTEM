import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-quiz-successful',
  templateUrl: './set-quiz-successful.component.html',
  styleUrls: ['./set-quiz-successful.component.css']
})
export class SetQuizSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
