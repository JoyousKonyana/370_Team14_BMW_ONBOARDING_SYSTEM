import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-quiz-confimation',
  templateUrl: './set-quiz-confimation.component.html',
  styleUrls: ['./set-quiz-confimation.component.css']
})
export class SetQuizConfimationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
