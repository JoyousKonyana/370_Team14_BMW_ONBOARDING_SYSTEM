import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SetQuizConfimationComponent } from './set-quiz-confimation.component';

describe('SetQuizConfimationComponent', () => {
  let component: SetQuizConfimationComponent;
  let fixture: ComponentFixture<SetQuizConfimationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SetQuizConfimationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SetQuizConfimationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
