import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SetQuizUnsuccessfulComponent } from './set-quiz-unsuccessful.component';

describe('SetQuizUnsuccessfulComponent', () => {
  let component: SetQuizUnsuccessfulComponent;
  let fixture: ComponentFixture<SetQuizUnsuccessfulComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SetQuizUnsuccessfulComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SetQuizUnsuccessfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
