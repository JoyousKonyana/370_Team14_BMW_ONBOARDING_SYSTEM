import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-quiz-unsuccessful',
  templateUrl: './set-quiz-unsuccessful.component.html',
  styleUrls: ['./set-quiz-unsuccessful.component.css']
})
export class SetQuizUnsuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
