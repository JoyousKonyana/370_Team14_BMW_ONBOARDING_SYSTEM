import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-archived-lesson-content-successfully',
  templateUrl: './delete-archived-lesson-content-successfully.component.html',
  styleUrls: ['./delete-archived-lesson-content-successfully.component.css']
})
export class DeleteArchivedLessonContentSuccessfullyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
