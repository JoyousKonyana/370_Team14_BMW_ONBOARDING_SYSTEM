import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteArchivedLessonContentSuccessfullyComponent } from './delete-archived-lesson-content-successfully.component';

describe('DeleteArchivedLessonContentSuccessfullyComponent', () => {
  let component: DeleteArchivedLessonContentSuccessfullyComponent;
  let fixture: ComponentFixture<DeleteArchivedLessonContentSuccessfullyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteArchivedLessonContentSuccessfullyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteArchivedLessonContentSuccessfullyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
