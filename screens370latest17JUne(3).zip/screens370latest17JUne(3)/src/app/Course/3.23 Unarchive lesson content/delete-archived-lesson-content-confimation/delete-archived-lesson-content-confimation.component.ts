import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-archived-lesson-content-confimation',
  templateUrl: './delete-archived-lesson-content-confimation.component.html',
  styleUrls: ['./delete-archived-lesson-content-confimation.component.css']
})
export class DeleteArchivedLessonContentConfimationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
