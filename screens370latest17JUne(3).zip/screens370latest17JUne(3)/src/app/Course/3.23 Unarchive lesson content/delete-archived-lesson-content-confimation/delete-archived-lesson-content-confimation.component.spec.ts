import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteArchivedLessonContentConfimationComponent } from './delete-archived-lesson-content-confimation.component';

describe('DeleteArchivedLessonContentConfimationComponent', () => {
  let component: DeleteArchivedLessonContentConfimationComponent;
  let fixture: ComponentFixture<DeleteArchivedLessonContentConfimationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteArchivedLessonContentConfimationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteArchivedLessonContentConfimationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
