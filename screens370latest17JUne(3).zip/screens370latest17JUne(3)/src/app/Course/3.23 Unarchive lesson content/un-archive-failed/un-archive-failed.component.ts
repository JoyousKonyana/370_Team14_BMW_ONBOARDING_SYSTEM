import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-un-archive-failed',
  templateUrl: './un-archive-failed.component.html',
  styleUrls: ['./un-archive-failed.component.css']
})
export class UnArchiveFailedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
