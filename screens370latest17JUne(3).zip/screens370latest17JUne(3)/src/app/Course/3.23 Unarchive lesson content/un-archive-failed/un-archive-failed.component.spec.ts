import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnArchiveFailedComponent } from './un-archive-failed.component';

describe('UnArchiveFailedComponent', () => {
  let component: UnArchiveFailedComponent;
  let fixture: ComponentFixture<UnArchiveFailedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnArchiveFailedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnArchiveFailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
