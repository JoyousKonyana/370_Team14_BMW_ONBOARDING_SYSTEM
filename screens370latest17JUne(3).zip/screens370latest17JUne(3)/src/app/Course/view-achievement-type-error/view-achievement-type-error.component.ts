import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-achievement-type-error',
  templateUrl: './view-achievement-type-error.component.html',
  styleUrls: ['./view-achievement-type-error.component.css']
})
export class ViewAchievementTypeErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
