import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAchievementTypeErrorComponent } from './view-achievement-type-error.component';

describe('ViewAchievementTypeErrorComponent', () => {
  let component: ViewAchievementTypeErrorComponent;
  let fixture: ComponentFixture<ViewAchievementTypeErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAchievementTypeErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAchievementTypeErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
