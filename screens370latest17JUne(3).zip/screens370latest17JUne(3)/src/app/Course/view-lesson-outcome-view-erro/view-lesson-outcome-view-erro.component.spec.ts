import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLessonOutcomeVIewErroComponent } from './view-lesson-outcome-view-erro.component';

describe('ViewLessonOutcomeVIewErroComponent', () => {
  let component: ViewLessonOutcomeVIewErroComponent;
  let fixture: ComponentFixture<ViewLessonOutcomeVIewErroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewLessonOutcomeVIewErroComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLessonOutcomeVIewErroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
