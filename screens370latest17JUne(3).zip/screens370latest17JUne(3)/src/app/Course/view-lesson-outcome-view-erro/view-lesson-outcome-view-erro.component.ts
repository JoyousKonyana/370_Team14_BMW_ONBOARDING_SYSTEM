import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-lesson-outcome-view-erro',
  templateUrl: './view-lesson-outcome-view-erro.component.html',
  styleUrls: ['./view-lesson-outcome-view-erro.component.css']
})
export class ViewLessonOutcomeVIewErroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
