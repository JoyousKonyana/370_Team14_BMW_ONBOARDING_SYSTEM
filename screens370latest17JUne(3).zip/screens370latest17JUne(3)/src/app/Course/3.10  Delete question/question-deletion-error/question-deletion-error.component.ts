import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-deletion-error',
  templateUrl: './question-deletion-error.component.html',
  styleUrls: ['./question-deletion-error.component.css']
})
export class QuestionDeletionErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
