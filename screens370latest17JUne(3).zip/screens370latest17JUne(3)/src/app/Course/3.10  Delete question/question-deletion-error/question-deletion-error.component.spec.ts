import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionDeletionErrorComponent } from './question-deletion-error.component';

describe('QuestionDeletionErrorComponent', () => {
  let component: QuestionDeletionErrorComponent;
  let fixture: ComponentFixture<QuestionDeletionErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestionDeletionErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionDeletionErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
