import { QuestionDeletedSuccessfullyComponent } from './../question-deleted-successfully/question-deleted-successfully.component';
import { QuestionDeletionErrorComponent } from './../question-deletion-error/question-deletion-error.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ViewCourseErrorComponent } from '../../3.2 View course/view-course-error/view-course-error.component';
import { DeleteQuestionConfirmComponent } from '../delete-question-confirm/delete-question-confirm.component';

export interface question {
  questionType: string;
  question: string ;
  answer: string;
  position: string;

}

const ELEMENT_DATA: question[] = [
  {position: '1',questionType: 'MCQ', question: 'ncnnccn', answer: 'MNCN QPQ'},
  {position: '2', questionType: 'T/F', question: 'ncnnccn', answer: 'T'},

];
@Component({
  selector: 'app-view-question-bank-questions',
  templateUrl: './view-question-bank-questions.component.html',
  styleUrls: ['./view-question-bank-questions.component.css']
})
export class ViewQuestionBankQuestionsComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  displayedColumns: string[] = ['#', 'Question Type', 'Question', 'Answer',
  'Actions'];
    dataSource = ELEMENT_DATA;
  
    openDialogViewCourseError() {
      const dialogRef = this.dialog.open(ViewCourseErrorComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }

    openDialogDeleteQuestion() {
      const dialogRef = this.dialog.open(DeleteQuestionConfirmComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
      }
      });
    }
    openDialogDeleteQuestionEr() {
      const dialogRef = this.dialog.open(QuestionDeletionErrorComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
      }
      });
    }

    openDialogDeleteQuestionDEleted() {
      const dialogRef = this.dialog.open(QuestionDeletedSuccessfullyComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
      }
      });
    }

}
