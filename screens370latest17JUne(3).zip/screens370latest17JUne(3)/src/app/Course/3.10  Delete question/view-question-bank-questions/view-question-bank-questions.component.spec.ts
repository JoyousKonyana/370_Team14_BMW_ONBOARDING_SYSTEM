import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewQuestionBankQuestionsComponent } from './view-question-bank-questions.component';

describe('ViewQuestionBankQuestionsComponent', () => {
  let component: ViewQuestionBankQuestionsComponent;
  let fixture: ComponentFixture<ViewQuestionBankQuestionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewQuestionBankQuestionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewQuestionBankQuestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
