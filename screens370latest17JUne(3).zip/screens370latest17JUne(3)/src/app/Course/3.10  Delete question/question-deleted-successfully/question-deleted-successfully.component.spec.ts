import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionDeletedSuccessfullyComponent } from './question-deleted-successfully.component';

describe('QuestionDeletedSuccessfullyComponent', () => {
  let component: QuestionDeletedSuccessfullyComponent;
  let fixture: ComponentFixture<QuestionDeletedSuccessfullyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestionDeletedSuccessfullyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionDeletedSuccessfullyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
