import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-deleted-successfully',
  templateUrl: './question-deleted-successfully.component.html',
  styleUrls: ['./question-deleted-successfully.component.css']
})
export class QuestionDeletedSuccessfullyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
