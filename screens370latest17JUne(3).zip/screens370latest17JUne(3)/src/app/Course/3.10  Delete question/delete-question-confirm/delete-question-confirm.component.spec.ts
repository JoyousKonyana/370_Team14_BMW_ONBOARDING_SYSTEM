import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteQuestionConfirmComponent } from './delete-question-confirm.component';

describe('DeleteQuestionConfirmComponent', () => {
  let component: DeleteQuestionConfirmComponent;
  let fixture: ComponentFixture<DeleteQuestionConfirmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteQuestionConfirmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteQuestionConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
