import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-question-confirm',
  templateUrl: './delete-question-confirm.component.html',
  styleUrls: ['./delete-question-confirm.component.css']
})
export class DeleteQuestionConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
