import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionDeleteUnsuccessfullComponent } from './question-delete-unsuccessfull.component';

describe('QuestionDeleteUnsuccessfullComponent', () => {
  let component: QuestionDeleteUnsuccessfullComponent;
  let fixture: ComponentFixture<QuestionDeleteUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestionDeleteUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionDeleteUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
