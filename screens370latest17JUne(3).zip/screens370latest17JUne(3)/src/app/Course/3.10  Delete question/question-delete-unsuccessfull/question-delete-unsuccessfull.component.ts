import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-delete-unsuccessfull',
  templateUrl: './question-delete-unsuccessfull.component.html',
  styleUrls: ['./question-delete-unsuccessfull.component.css']
})
export class QuestionDeleteUnsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
