import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-lessonoutcome-confirmation',
  templateUrl: './delete-lessonoutcome-confirmation.component.html',
  styleUrls: ['./delete-lessonoutcome-confirmation.component.css']
})
export class DeleteLessonoutcomeConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
