import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteLessonoutcomeConfirmationComponent } from './delete-lessonoutcome-confirmation.component';

describe('DeleteLessonoutcomeConfirmationComponent', () => {
  let component: DeleteLessonoutcomeConfirmationComponent;
  let fixture: ComponentFixture<DeleteLessonoutcomeConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteLessonoutcomeConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteLessonoutcomeConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
