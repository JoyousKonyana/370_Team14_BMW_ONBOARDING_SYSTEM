import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lesson-outcome-deletionunsuccesfull',
  templateUrl: './lesson-outcome-deletionunsuccesfull.component.html',
  styleUrls: ['./lesson-outcome-deletionunsuccesfull.component.css']
})
export class LessonOutcomeDeletionunsuccesfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
