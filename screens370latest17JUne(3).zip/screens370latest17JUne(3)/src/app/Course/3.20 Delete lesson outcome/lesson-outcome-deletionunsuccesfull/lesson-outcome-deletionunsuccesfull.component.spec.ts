import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LessonOutcomeDeletionunsuccesfullComponent } from './lesson-outcome-deletionunsuccesfull.component';

describe('LessonOutcomeDeletionunsuccesfullComponent', () => {
  let component: LessonOutcomeDeletionunsuccesfullComponent;
  let fixture: ComponentFixture<LessonOutcomeDeletionunsuccesfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LessonOutcomeDeletionunsuccesfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LessonOutcomeDeletionunsuccesfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
