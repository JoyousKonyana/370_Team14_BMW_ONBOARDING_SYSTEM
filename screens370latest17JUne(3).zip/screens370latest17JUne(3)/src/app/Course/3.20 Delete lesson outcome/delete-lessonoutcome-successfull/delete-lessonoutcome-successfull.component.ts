import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-lessonoutcome-successfull',
  templateUrl: './delete-lessonoutcome-successfull.component.html',
  styleUrls: ['./delete-lessonoutcome-successfull.component.css']
})
export class DeleteLessonoutcomeSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
