import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteLessonoutcomeSuccessfullComponent } from './delete-lessonoutcome-successfull.component';

describe('DeleteLessonoutcomeSuccessfullComponent', () => {
  let component: DeleteLessonoutcomeSuccessfullComponent;
  let fixture: ComponentFixture<DeleteLessonoutcomeSuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteLessonoutcomeSuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteLessonoutcomeSuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
