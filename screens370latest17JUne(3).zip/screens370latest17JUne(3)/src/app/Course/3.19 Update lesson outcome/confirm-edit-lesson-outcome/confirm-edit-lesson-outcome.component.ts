import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-edit-lesson-outcome',
  templateUrl: './confirm-edit-lesson-outcome.component.html',
  styleUrls: ['./confirm-edit-lesson-outcome.component.css']
})
export class ConfirmEditLessonOutcomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
