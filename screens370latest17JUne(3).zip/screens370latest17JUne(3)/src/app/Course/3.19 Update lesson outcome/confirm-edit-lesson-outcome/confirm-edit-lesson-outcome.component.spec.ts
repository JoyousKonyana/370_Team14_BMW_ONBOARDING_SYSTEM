import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmEditLessonOutcomeComponent } from './confirm-edit-lesson-outcome.component';

describe('ConfirmEditLessonOutcomeComponent', () => {
  let component: ConfirmEditLessonOutcomeComponent;
  let fixture: ComponentFixture<ConfirmEditLessonOutcomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmEditLessonOutcomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmEditLessonOutcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
