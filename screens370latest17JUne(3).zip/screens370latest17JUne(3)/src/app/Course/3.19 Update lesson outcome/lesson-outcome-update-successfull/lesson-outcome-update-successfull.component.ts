import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lesson-outcome-update-successfull',
  templateUrl: './lesson-outcome-update-successfull.component.html',
  styleUrls: ['./lesson-outcome-update-successfull.component.css']
})
export class LessonOutcomeUpdateSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
