import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LessonOutcomeUpdateSuccessfullComponent } from './lesson-outcome-update-successfull.component';

describe('LessonOutcomeUpdateSuccessfullComponent', () => {
  let component: LessonOutcomeUpdateSuccessfullComponent;
  let fixture: ComponentFixture<LessonOutcomeUpdateSuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LessonOutcomeUpdateSuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LessonOutcomeUpdateSuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
