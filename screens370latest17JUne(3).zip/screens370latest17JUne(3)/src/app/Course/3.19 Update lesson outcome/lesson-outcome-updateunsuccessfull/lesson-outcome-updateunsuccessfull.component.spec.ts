import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LessonOutcomeUpdateunsuccessfullComponent } from './lesson-outcome-updateunsuccessfull.component';

describe('LessonOutcomeUpdateunsuccessfullComponent', () => {
  let component: LessonOutcomeUpdateunsuccessfullComponent;
  let fixture: ComponentFixture<LessonOutcomeUpdateunsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LessonOutcomeUpdateunsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LessonOutcomeUpdateunsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
