import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lesson-outcome-updateunsuccessfull',
  templateUrl: './lesson-outcome-updateunsuccessfull.component.html',
  styleUrls: ['./lesson-outcome-updateunsuccessfull.component.css']
})
export class LessonOutcomeUpdateunsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
