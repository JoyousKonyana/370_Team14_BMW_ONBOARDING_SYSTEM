import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditLessonOutcomeComponent } from './edit-lesson-outcome.component';

describe('EditLessonOutcomeComponent', () => {
  let component: EditLessonOutcomeComponent;
  let fixture: ComponentFixture<EditLessonOutcomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditLessonOutcomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditLessonOutcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
