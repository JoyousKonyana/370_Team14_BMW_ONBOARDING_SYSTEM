import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmEditLessonOutcomeComponent } from '../confirm-edit-lesson-outcome/confirm-edit-lesson-outcome.component';
import { LessonOutcomeUpdateSuccessfullComponent } from '../lesson-outcome-update-successfull/lesson-outcome-update-successfull.component';
import { LessonOutcomeUpdateunsuccessfullComponent } from '../lesson-outcome-updateunsuccessfull/lesson-outcome-updateunsuccessfull.component';
import { LessonoutcomeUpdateSuccessfullComponent } from '../lessonoutcome-update-successfull/lessonoutcome-update-successfull.component';
@Component({
  selector: 'app-edit-lesson-outcome',
  templateUrl: './edit-lesson-outcome.component.html',
  styleUrls: ['./edit-lesson-outcome.component.css']
})
export class EditLessonOutcomeComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }


  openDialoglessonOutcomecreationfailed() {
    const dialogRef = this.dialog.open(ConfirmEditLessonOutcomeComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialoglessonOutcomecreationsuccess() {
    const dialogRef = this.dialog.open(LessonOutcomeUpdateSuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }


  openDialoglessonOutcomecreationunsuccess() {
    const dialogRef = this.dialog.open(LessonOutcomeUpdateunsuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }
}
