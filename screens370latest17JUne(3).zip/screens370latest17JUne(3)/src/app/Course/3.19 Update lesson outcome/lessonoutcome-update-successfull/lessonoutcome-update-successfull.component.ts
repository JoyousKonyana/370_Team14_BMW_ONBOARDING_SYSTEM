import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lessonoutcome-update-successfull',
  templateUrl: './lessonoutcome-update-successfull.component.html',
  styleUrls: ['./lessonoutcome-update-successfull.component.css']
})
export class LessonoutcomeUpdateSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
