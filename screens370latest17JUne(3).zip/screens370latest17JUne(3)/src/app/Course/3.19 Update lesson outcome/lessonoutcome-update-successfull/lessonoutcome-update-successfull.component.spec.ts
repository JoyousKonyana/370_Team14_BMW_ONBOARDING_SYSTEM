import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LessonoutcomeUpdateSuccessfullComponent } from './lessonoutcome-update-successfull.component';

describe('LessonoutcomeUpdateSuccessfullComponent', () => {
  let component: LessonoutcomeUpdateSuccessfullComponent;
  let fixture: ComponentFixture<LessonoutcomeUpdateSuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LessonoutcomeUpdateSuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LessonoutcomeUpdateSuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
