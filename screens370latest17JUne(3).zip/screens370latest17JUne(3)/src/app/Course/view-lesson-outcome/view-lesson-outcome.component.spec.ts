import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLessonOutcomeComponent } from './view-lesson-outcome.component';

describe('ViewLessonOutcomeComponent', () => {
  let component: ViewLessonOutcomeComponent;
  let fixture: ComponentFixture<ViewLessonOutcomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewLessonOutcomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLessonOutcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
