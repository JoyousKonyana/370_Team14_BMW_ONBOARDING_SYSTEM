import { LessonOutcomeComponent } from './../3.18 Create lesson outcome/lesson-outcome/lesson-outcome.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteLessonoutcomeConfirmationComponent } from '../3.20 Delete lesson outcome/delete-lessonoutcome-confirmation/delete-lessonoutcome-confirmation.component';
import { EditLessonOutcomeComponent } from '../3.19 Update lesson outcome/edit-lesson-outcome/edit-lesson-outcome.component';
import { ViewLessonOutcomeVIewErroComponent } from '../view-lesson-outcome-view-erro/view-lesson-outcome-view-erro.component';
import { DeleteLessonoutcomeSuccessfullComponent } from '../3.20 Delete lesson outcome/delete-lessonoutcome-successfull/delete-lessonoutcome-successfull.component';
import { LessonOutcomeDeletionunsuccesfullComponent } from '../3.20 Delete lesson outcome/lesson-outcome-deletionunsuccesfull/lesson-outcome-deletionunsuccesfull.component';

export interface lessonOutcomes {
  name: string;
  position: number;
  description: string;

}

const ELEMENT_DATA: lessonOutcomes[] = [
  {position: 1, name: 'Lesson Outcome 1', description: 'This lesson outcome is an introduction to everything to sexaul harrassmnet in a work place '},
  // {position: 2, name: 'Lesson Outcome 2', description: 'This lesson outcome is an introduction to everything '},
];
@Component({
  selector: 'app-view-lesson-outcome',
  templateUrl: './view-lesson-outcome.component.html',
  styleUrls: ['./view-lesson-outcome.component.css']
})

export class ViewLessonOutcomeComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {

    // this.openDialogVIewlesosonoutcomeError();
  }
  displayedColumns: string[] = ['#', 'Name', 'Description',
  'Actions'];
    dataSource = ELEMENT_DATA;

    openDialogEditLessonOutcome() {
      const dialogRef = this.dialog.open(EditLessonOutcomeComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }


    openDialogDeleteConfirmationDialogue() {
      const dialogRef = this.dialog.open(DeleteLessonoutcomeConfirmationComponent);
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogDeleteLessonoutcomeSuccess() {
      const dialogRef = this.dialog.open(DeleteLessonoutcomeSuccessfullComponent);
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }
    openDialogVIewlesosonoutcomeError() {
      const dialogRef = this.dialog.open(ViewLessonOutcomeVIewErroComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogVIewlesosonoutcomedlete() {
      const dialogRef = this.dialog.open(LessonOutcomeDeletionunsuccesfullComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogAddLessonOutcome() {
      const dialogRef = this.dialog.open(LessonOutcomeComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }
}
