import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminLanding2Component } from './admin-landing2.component';

describe('AdminLanding2Component', () => {
  let component: AdminLanding2Component;
  let fixture: ComponentFixture<AdminLanding2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminLanding2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminLanding2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
