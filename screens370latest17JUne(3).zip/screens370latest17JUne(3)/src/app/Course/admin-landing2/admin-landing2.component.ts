import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-landing2',
  templateUrl: './admin-landing2.component.html',
  styleUrls: ['./admin-landing2.component.css']
})
export class AdminLanding2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
