import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LessonoutcomeCreationfailureComponent } from './lessonoutcome-creationfailure.component';

describe('LessonoutcomeCreationfailureComponent', () => {
  let component: LessonoutcomeCreationfailureComponent;
  let fixture: ComponentFixture<LessonoutcomeCreationfailureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LessonoutcomeCreationfailureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LessonoutcomeCreationfailureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
