import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lessonoutcome-creationfailure',
  templateUrl: './lessonoutcome-creationfailure.component.html',
  styleUrls: ['./lessonoutcome-creationfailure.component.css']
})
export class LessonoutcomeCreationfailureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
