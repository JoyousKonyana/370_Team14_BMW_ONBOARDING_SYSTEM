import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComfirmLessonOutcomeCreationComponent } from './comfirm-lesson-outcome-creation.component';

describe('ComfirmLessonOutcomeCreationComponent', () => {
  let component: ComfirmLessonOutcomeCreationComponent;
  let fixture: ComponentFixture<ComfirmLessonOutcomeCreationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComfirmLessonOutcomeCreationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComfirmLessonOutcomeCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
