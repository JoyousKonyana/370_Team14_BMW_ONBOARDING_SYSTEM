import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comfirm-lesson-outcome-creation',
  templateUrl: './comfirm-lesson-outcome-creation.component.html',
  styleUrls: ['./comfirm-lesson-outcome-creation.component.css']
})
export class ComfirmLessonOutcomeCreationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
