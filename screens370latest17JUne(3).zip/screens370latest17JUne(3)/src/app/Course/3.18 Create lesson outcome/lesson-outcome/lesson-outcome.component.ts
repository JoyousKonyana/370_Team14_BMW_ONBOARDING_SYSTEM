import { LessonOutcomeCreationSuccessComponent } from './../lesson-outcome-creation-success/lesson-outcome-creation-success.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ComfirmLessonOutcomeCreationComponent } from '../comfirm-lesson-outcome-creation/comfirm-lesson-outcome-creation.component';
import { LessonoutcomeCreationfailureComponent } from '../lessonoutcome-creationfailure/lessonoutcome-creationfailure.component';
@Component({
  selector: 'app-lesson-outcome',
  templateUrl: './lesson-outcome.component.html',
  styleUrls: ['./lesson-outcome.component.css']
})
export class LessonOutcomeComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }


  openDialogConfirmlessonoutcomeCreation() {
    const dialogRef = this.dialog.open(ComfirmLessonOutcomeCreationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialoglessonoutcomeCreationSuccessfull() {
    const dialogRef = this.dialog.open(LessonOutcomeCreationSuccessComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialoglessonoutcomeCreationunSuccessfull() {
    const dialogRef = this.dialog.open(LessonoutcomeCreationfailureComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

}
