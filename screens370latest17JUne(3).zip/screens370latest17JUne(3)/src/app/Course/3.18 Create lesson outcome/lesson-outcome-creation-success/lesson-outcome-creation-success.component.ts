import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lesson-outcome-creation-success',
  templateUrl: './lesson-outcome-creation-success.component.html',
  styleUrls: ['./lesson-outcome-creation-success.component.css']
})
export class LessonOutcomeCreationSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
