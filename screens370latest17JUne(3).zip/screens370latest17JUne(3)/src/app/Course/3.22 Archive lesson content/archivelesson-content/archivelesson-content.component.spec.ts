import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivelessonContentComponent } from './archivelesson-content.component';

describe('ArchivelessonContentComponent', () => {
  let component: ArchivelessonContentComponent;
  let fixture: ComponentFixture<ArchivelessonContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArchivelessonContentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivelessonContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
