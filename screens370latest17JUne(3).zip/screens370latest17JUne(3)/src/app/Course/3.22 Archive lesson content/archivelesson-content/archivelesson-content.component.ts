import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ComfirmLessonContentArchiveComponent } from '../comfirm-lesson-content-archive/comfirm-lesson-content-archive.component';
import { LessonContentAchirvedSuccefullyComponent } from '../lesson-content-achirved-succefully/lesson-content-achirved-succefully.component';
import { LessonUnsuccessfullyArchivedComponent } from '../lesson-unsuccessfully-archived/lesson-unsuccessfully-archived.component';

export interface lessoncontent {

  position: number;
  description: string;
  lesson: string;
  contentType: string;

}

const ELEMENT_DATA: lessoncontent[] = [
  {position: 1,  description: 'This file contains learning material related to lesson 1', lesson: 'lesson 1', contentType: 'MP4'},
  {position: 2, description: 'This file contains learning material related to lesson 1', lesson: 'lesson 1', contentType: 'MP4'},
];
@Component({
  selector: 'app-archivelesson-content',
  templateUrl: './archivelesson-content.component.html',
  styleUrls: ['./archivelesson-content.component.css']
})
export class ArchivelessonContentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.openDialogArchivelessonContentunSuccessfull();
  }
  displayedColumns: string[] = ['#','Description','Lesson','Content Type',
  'Actions'];
    dataSource = ELEMENT_DATA;


    openDialogEditLessonOutcome(){
        alert('Hello');
    }

    openDialogConfirmArchive() {
      const dialogRef = this.dialog.open(ComfirmLessonContentArchiveComponent);
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }

    openDialogArchivelessonContentSuccessfull() {
      const dialogRef = this.dialog.open(LessonContentAchirvedSuccefullyComponent);
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }


    openDialogArchivelessonContentunSuccessfull() {
      const dialogRef = this.dialog.open(LessonUnsuccessfullyArchivedComponent);
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }
}
