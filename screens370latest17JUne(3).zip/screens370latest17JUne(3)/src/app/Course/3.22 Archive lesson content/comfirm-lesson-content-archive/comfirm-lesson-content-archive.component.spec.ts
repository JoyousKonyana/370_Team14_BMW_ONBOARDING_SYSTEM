import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComfirmLessonContentArchiveComponent } from './comfirm-lesson-content-archive.component';

describe('ComfirmLessonContentArchiveComponent', () => {
  let component: ComfirmLessonContentArchiveComponent;
  let fixture: ComponentFixture<ComfirmLessonContentArchiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComfirmLessonContentArchiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComfirmLessonContentArchiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
