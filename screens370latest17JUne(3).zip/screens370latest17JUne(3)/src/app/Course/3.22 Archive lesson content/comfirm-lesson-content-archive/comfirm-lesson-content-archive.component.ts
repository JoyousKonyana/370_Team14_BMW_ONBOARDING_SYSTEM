import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comfirm-lesson-content-archive',
  templateUrl: './comfirm-lesson-content-archive.component.html',
  styleUrls: ['./comfirm-lesson-content-archive.component.css']
})
export class ComfirmLessonContentArchiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
