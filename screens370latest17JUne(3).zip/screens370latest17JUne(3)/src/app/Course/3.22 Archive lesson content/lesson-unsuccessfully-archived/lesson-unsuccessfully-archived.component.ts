import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lesson-unsuccessfully-archived',
  templateUrl: './lesson-unsuccessfully-archived.component.html',
  styleUrls: ['./lesson-unsuccessfully-archived.component.css']
})
export class LessonUnsuccessfullyArchivedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
