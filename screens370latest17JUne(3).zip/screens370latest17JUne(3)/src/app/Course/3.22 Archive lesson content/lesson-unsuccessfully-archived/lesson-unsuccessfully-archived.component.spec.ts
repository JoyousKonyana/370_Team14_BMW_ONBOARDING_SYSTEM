import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LessonUnsuccessfullyArchivedComponent } from './lesson-unsuccessfully-archived.component';

describe('LessonUnsuccessfullyArchivedComponent', () => {
  let component: LessonUnsuccessfullyArchivedComponent;
  let fixture: ComponentFixture<LessonUnsuccessfullyArchivedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LessonUnsuccessfullyArchivedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LessonUnsuccessfullyArchivedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
