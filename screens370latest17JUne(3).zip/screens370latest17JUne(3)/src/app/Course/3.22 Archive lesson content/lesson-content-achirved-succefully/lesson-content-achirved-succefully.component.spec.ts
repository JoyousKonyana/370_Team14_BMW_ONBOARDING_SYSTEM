import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LessonContentAchirvedSuccefullyComponent } from './lesson-content-achirved-succefully.component';

describe('LessonContentAchirvedSuccefullyComponent', () => {
  let component: LessonContentAchirvedSuccefullyComponent;
  let fixture: ComponentFixture<LessonContentAchirvedSuccefullyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LessonContentAchirvedSuccefullyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LessonContentAchirvedSuccefullyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
