import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lesson-content-achirved-succefully',
  templateUrl: './lesson-content-achirved-succefully.component.html',
  styleUrls: ['./lesson-content-achirved-succefully.component.css']
})
export class LessonContentAchirvedSuccefullyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
