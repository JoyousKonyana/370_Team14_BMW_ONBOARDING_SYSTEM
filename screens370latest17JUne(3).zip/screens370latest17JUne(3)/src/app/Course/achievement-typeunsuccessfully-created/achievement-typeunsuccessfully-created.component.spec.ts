import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchievementTYpeunsuccessfullyCreatedComponent } from './achievement-typeunsuccessfully-created.component';

describe('AchievementTYpeunsuccessfullyCreatedComponent', () => {
  let component: AchievementTYpeunsuccessfullyCreatedComponent;
  let fixture: ComponentFixture<AchievementTYpeunsuccessfullyCreatedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AchievementTYpeunsuccessfullyCreatedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AchievementTYpeunsuccessfullyCreatedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
