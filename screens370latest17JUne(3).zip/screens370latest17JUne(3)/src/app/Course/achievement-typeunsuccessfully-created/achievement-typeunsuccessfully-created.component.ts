import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achievement-typeunsuccessfully-created',
  templateUrl: './achievement-typeunsuccessfully-created.component.html',
  styleUrls: ['./achievement-typeunsuccessfully-created.component.css']
})
export class AchievementTYpeunsuccessfullyCreatedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
