import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports-screen',
  templateUrl: './reports-screen.component.html',
  styleUrls: ['./reports-screen.component.css']
})
export class ReportsScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
