import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboarderProgressReportComponent } from './onboarder-progress-report.component';

describe('OnboarderProgressReportComponent', () => {
  let component: OnboarderProgressReportComponent;
  let fixture: ComponentFixture<OnboarderProgressReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OnboarderProgressReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboarderProgressReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
