import { Component, OnInit } from '@angular/core';
export interface AssignedEquipment {
 
  topic:string;
  startDate:string;
  endDate:string;



}

const ELEMENT_DATA: AssignedEquipment[] = [
  {topic: 'Team Dynamics', startDate: "01 June 2021", endDate: '07 JUne 2021'},
  {topic: 'Respect in the workplace', startDate: "05 June 2021", endDate: '07 JUne 2021'},
  {topic: 'Humanity', startDate: "04 June 2021", endDate: '-'},

];
@Component({
  selector: 'app-onboarder-progress-report',
  templateUrl: './onboarder-progress-report.component.html',
  styleUrls: ['./onboarder-progress-report.component.css']
})
export class OnboarderProgressReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  displayedColumns: string[] = ['Topic', 'Start date', 'End date', 'Progress', 
  ];
    dataSource = ELEMENT_DATA;

}
