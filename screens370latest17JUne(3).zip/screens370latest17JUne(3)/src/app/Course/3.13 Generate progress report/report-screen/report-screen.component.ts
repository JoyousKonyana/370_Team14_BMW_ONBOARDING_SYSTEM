import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-screen',
  templateUrl: './report-screen.component.html',
  styleUrls: ['./report-screen.component.css']
})
export class ReportScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
