import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateCourseProgressComponent } from './generate-course-progress.component';

describe('GenerateCourseProgressComponent', () => {
  let component: GenerateCourseProgressComponent;
  let fixture: ComponentFixture<GenerateCourseProgressComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenerateCourseProgressComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateCourseProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
