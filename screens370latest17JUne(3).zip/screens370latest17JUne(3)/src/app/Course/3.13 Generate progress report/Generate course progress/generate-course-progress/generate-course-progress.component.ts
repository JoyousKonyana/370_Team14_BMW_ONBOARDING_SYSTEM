import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generate-course-progress',
  templateUrl: './generate-course-progress.component.html',
  styleUrls: ['./generate-course-progress.component.css']
})
export class GenerateCourseProgressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
