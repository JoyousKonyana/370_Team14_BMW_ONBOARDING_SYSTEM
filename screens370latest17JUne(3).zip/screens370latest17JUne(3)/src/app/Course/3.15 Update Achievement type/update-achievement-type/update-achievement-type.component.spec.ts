import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAchievementTypeComponent } from './update-achievement-type.component';

describe('UpdateAchievementTypeComponent', () => {
  let component: UpdateAchievementTypeComponent;
  let fixture: ComponentFixture<UpdateAchievementTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateAchievementTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateAchievementTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
