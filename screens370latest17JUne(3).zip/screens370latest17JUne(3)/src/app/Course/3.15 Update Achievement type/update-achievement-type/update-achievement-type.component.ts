import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AchievementTYpeunsuccessfullyCreatedComponent } from '../../achievement-typeunsuccessfully-created/achievement-typeunsuccessfully-created.component';
import { AchievementTYpeUpdateSuccessfullComponent } from '../achievement-type-update-successfull/achievement-type-update-successfull.component';
import { AchievementTypeupdateUnsuccessfullComponent } from '../achievement-typeupdate-unsuccessfull/achievement-typeupdate-unsuccessfull.component';
import { ConfirmAchievementTypeUpdateComponent } from '../confirm-achievement-type-update/confirm-achievement-type-update.component';
@Component({
  selector: 'app-update-achievement-type',
  templateUrl: './update-achievement-type.component.html',
  styleUrls: ['./update-achievement-type.component.css']
})
export class UpdateAchievementTypeComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogConfirmAchievmentTYpeCreationSuccess() {
    const dialogRef = this.dialog.open(AchievementTYpeUpdateSuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });    
  }

  openDialogConfirmAchievmentTYpeCreationUNSuccess() {
    const dialogRef = this.dialog.open(AchievementTypeupdateUnsuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });    
  }

  openDialogConfirmAchievmentTYpeConfirm() {
    const dialogRef = this.dialog.open(ConfirmAchievementTypeUpdateComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });    
  }

}
