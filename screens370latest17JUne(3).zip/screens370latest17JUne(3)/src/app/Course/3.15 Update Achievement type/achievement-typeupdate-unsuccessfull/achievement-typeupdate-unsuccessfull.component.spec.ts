import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchievementTypeupdateUnsuccessfullComponent } from './achievement-typeupdate-unsuccessfull.component';

describe('AchievementTypeupdateUnsuccessfullComponent', () => {
  let component: AchievementTypeupdateUnsuccessfullComponent;
  let fixture: ComponentFixture<AchievementTypeupdateUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AchievementTypeupdateUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AchievementTypeupdateUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
