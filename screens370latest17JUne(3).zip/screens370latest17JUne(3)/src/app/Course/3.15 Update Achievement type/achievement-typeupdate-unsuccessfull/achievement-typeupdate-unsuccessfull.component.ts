import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achievement-typeupdate-unsuccessfull',
  templateUrl: './achievement-typeupdate-unsuccessfull.component.html',
  styleUrls: ['./achievement-typeupdate-unsuccessfull.component.css']
})
export class AchievementTypeupdateUnsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
