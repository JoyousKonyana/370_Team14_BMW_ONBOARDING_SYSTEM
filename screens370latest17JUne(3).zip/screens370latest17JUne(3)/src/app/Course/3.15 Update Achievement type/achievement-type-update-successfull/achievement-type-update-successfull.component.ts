import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achievement-type-update-successfull',
  templateUrl: './achievement-type-update-successfull.component.html',
  styleUrls: ['./achievement-type-update-successfull.component.css']
})
export class AchievementTYpeUpdateSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
