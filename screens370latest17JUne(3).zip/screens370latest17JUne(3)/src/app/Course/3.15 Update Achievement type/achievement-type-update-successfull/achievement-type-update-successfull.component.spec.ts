import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchievementTYpeUpdateSuccessfullComponent } from './achievement-type-update-successfull.component';

describe('AchievementTYpeUpdateSuccessfullComponent', () => {
  let component: AchievementTYpeUpdateSuccessfullComponent;
  let fixture: ComponentFixture<AchievementTYpeUpdateSuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AchievementTYpeUpdateSuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AchievementTYpeUpdateSuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
