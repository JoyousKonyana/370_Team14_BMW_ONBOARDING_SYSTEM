import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmAchievementTypeUpdateComponent } from './confirm-achievement-type-update.component';

describe('ConfirmAchievementTypeUpdateComponent', () => {
  let component: ConfirmAchievementTypeUpdateComponent;
  let fixture: ComponentFixture<ConfirmAchievementTypeUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmAchievementTypeUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmAchievementTypeUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
