import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-achievement-type-update',
  templateUrl: './confirm-achievement-type-update.component.html',
  styleUrls: ['./confirm-achievement-type-update.component.css']
})
export class ConfirmAchievementTypeUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
