import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achievement-type-created-successfull',
  templateUrl: './achievement-type-created-successfull.component.html',
  styleUrls: ['./achievement-type-created-successfull.component.css']
})
export class AchievementTypeCreatedSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
