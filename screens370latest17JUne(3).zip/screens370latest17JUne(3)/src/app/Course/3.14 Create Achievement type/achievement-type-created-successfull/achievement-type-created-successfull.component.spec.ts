import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchievementTypeCreatedSuccessfullComponent } from './achievement-type-created-successfull.component';

describe('AchievementTypeCreatedSuccessfullComponent', () => {
  let component: AchievementTypeCreatedSuccessfullComponent;
  let fixture: ComponentFixture<AchievementTypeCreatedSuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AchievementTypeCreatedSuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AchievementTypeCreatedSuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
