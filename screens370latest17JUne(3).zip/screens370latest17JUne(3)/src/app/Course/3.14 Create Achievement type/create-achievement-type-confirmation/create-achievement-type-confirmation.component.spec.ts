import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAchievementTypeConfirmationComponent } from './create-achievement-type-confirmation.component';

describe('CreateAchievementTypeConfirmationComponent', () => {
  let component: CreateAchievementTypeConfirmationComponent;
  let fixture: ComponentFixture<CreateAchievementTypeConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateAchievementTypeConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateAchievementTypeConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
