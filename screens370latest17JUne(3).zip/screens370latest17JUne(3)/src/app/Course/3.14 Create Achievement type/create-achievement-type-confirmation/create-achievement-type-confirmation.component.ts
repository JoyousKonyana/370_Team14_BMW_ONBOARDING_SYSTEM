import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-achievement-type-confirmation',
  templateUrl: './create-achievement-type-confirmation.component.html',
  styleUrls: ['./create-achievement-type-confirmation.component.css']
})
export class CreateAchievementTypeConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
