import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAchievementTypeUnsuccessfullComponent } from './create-achievement-type-unsuccessfull.component';

describe('CreateAchievementTypeUnsuccessfullComponent', () => {
  let component: CreateAchievementTypeUnsuccessfullComponent;
  let fixture: ComponentFixture<CreateAchievementTypeUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateAchievementTypeUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateAchievementTypeUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
