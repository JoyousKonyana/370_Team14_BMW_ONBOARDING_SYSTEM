import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-achievement-type-unsuccessfull',
  templateUrl: './create-achievement-type-unsuccessfull.component.html',
  styleUrls: ['./create-achievement-type-unsuccessfull.component.css']
})
export class CreateAchievementTypeUnsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
