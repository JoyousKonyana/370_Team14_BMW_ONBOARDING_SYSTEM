import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAchievementTypeComponent } from './create-achievement-type.component';

describe('CreateAchievementTypeComponent', () => {
  let component: CreateAchievementTypeComponent;
  let fixture: ComponentFixture<CreateAchievementTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateAchievementTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateAchievementTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
