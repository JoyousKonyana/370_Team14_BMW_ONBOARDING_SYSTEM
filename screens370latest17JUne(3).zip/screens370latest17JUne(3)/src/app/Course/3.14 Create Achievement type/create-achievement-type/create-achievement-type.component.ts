import { AchievementTypeCreatedSuccessfullComponent } from './../achievement-type-created-successfull/achievement-type-created-successfull.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AchievementTYpeunsuccessfullyCreatedComponent } from '../../achievement-typeunsuccessfully-created/achievement-typeunsuccessfully-created.component';
import { CreateAchievementTypeUnsuccessfullComponent } from '../create-achievement-type-unsuccessfull/create-achievement-type-unsuccessfull.component';
import { CreateAchievementTypeConfirmationComponent } from '../create-achievement-type-confirmation/create-achievement-type-confirmation.component';
@Component({
  selector: 'app-create-achievement-type',
  templateUrl: './create-achievement-type.component.html',
  styleUrls: ['./create-achievement-type.component.css']
})
export class CreateAchievementTypeComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogAchievmentTYpeCreatedSuccessfull() {
    const dialogRef = this.dialog.open(AchievementTypeCreatedSuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });    
  }

  openDialogAchievmentTYpeCreatedunSuccessfull() {
    const dialogRef = this.dialog.open(CreateAchievementTypeUnsuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });    
  }

  openDialogConfirmAchievmentTYpeCreation() {
    const dialogRef = this.dialog.open(CreateAchievementTypeConfirmationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){

    }
    });    
  }
}
