import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-view-archived-lesson-content-error',
  templateUrl: './view-archived-lesson-content-error.component.html',
  styleUrls: ['./view-archived-lesson-content-error.component.css']
})
export class ViewArchivedLessonContentErrorComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

 

}
