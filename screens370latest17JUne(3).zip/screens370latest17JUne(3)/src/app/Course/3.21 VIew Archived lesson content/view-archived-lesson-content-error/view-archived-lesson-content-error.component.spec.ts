import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewArchivedLessonContentErrorComponent } from './view-archived-lesson-content-error.component';

describe('ViewArchivedLessonContentErrorComponent', () => {
  let component: ViewArchivedLessonContentErrorComponent;
  let fixture: ComponentFixture<ViewArchivedLessonContentErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewArchivedLessonContentErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewArchivedLessonContentErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
