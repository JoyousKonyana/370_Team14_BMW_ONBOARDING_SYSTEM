import { SearchARcivedLessonContentCouldnotFindMatchComponent } from './../../3.24 Search archived lesson content/search-arcived-lesson-content-couldnot-find-match/search-arcived-lesson-content-couldnot-find-match.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteLessonoutcomeConfirmationComponent } from '../../3.20 Delete lesson outcome/delete-lessonoutcome-confirmation/delete-lessonoutcome-confirmation.component';
import { ComfirmLessonContentArchiveComponent } from '../../3.22 Archive lesson content/comfirm-lesson-content-archive/comfirm-lesson-content-archive.component';
import { DeleteArchivedLessonContentConfimationComponent } from '../../3.23 Unarchive lesson content/delete-archived-lesson-content-confimation/delete-archived-lesson-content-confimation.component';
import { UnArchiveFailedComponent } from '../../3.23 Unarchive lesson content/un-archive-failed/un-archive-failed.component';
import { ViewArchivedLessonContentErrorComponent } from '../view-archived-lesson-content-error/view-archived-lesson-content-error.component';
export interface archivedLessonContent {

  position: number;
  description: string;
  lesson:string;
  contentType: string;

}

const ELEMENT_DATA: archivedLessonContent[] = [
  {position: 1, description: 'This lesson content has the introduction to work ethics', lesson: 'Lesson 1', contentType: 'MP4'},
  {position: 2, description: 'This lesson content has the introduction to how to be productive during Covid times', lesson: 'Lesson 1', contentType: 'MP4'},

];

@Component({
  selector: 'app-view-archived-lesson-content',
  templateUrl: './view-archived-lesson-content.component.html',
  styleUrls: ['./view-archived-lesson-content.component.css']
})
export class ViewArchivedLessonContentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    // this.openDialogSearchfailed();

    // this.openDialogUnarchveFailed();
    // this.openDialogConfirmdeleteArchive();
    // this.openDialogConfirmArchive();
    // this.openDialogViewArchivedlessonContent();
  }
  displayedColumns: string[] = ['#','Description', 'Lesson', 'Content Type',
  'UnArchive'];
    dataSource = ELEMENT_DATA;

  openDialogDeleteConfirmationDialogue() {
    const dialogRef = this.dialog.open(DeleteLessonoutcomeConfirmationComponent);
    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogViewArchivedlessonContent() {
    const dialogRef = this.dialog.open(ViewArchivedLessonContentErrorComponent);
    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }
  
  openDialogConfirmArchive() {
    const dialogRef = this.dialog.open(ComfirmLessonContentArchiveComponent);
    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogConfirmdeleteArchive() {
    const dialogRef = this.dialog.open(DeleteArchivedLessonContentConfimationComponent);
    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogConfirmdeleteArchve() {
    const dialogRef = this.dialog.open(DeleteArchivedLessonContentConfimationComponent);
    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogUnarchveFailed() {
    const dialogRef = this.dialog.open(UnArchiveFailedComponent);
    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogConfirmUnarchveFailed() {
    const dialogRef = this.dialog.open(DeleteArchivedLessonContentConfimationComponent);
    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogSearchfailed() {
    const dialogRef = this.dialog.open(SearchARcivedLessonContentCouldnotFindMatchComponent);
    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

}
