import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewArchivedLessonContentComponent } from './view-archived-lesson-content.component';

describe('ViewArchivedLessonContentComponent', () => {
  let component: ViewArchivedLessonContentComponent;
  let fixture: ComponentFixture<ViewArchivedLessonContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewArchivedLessonContentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewArchivedLessonContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
