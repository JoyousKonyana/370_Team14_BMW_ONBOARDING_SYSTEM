import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseCreationfailureComponent } from './course-creationfailure.component';

describe('CourseCreationfailureComponent', () => {
  let component: CourseCreationfailureComponent;
  let fixture: ComponentFixture<CourseCreationfailureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseCreationfailureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseCreationfailureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
