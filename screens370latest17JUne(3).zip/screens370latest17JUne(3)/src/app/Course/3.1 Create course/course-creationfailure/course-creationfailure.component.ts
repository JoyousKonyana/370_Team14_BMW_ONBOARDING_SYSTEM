import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-creationfailure',
  templateUrl: './course-creationfailure.component.html',
  styleUrls: ['./course-creationfailure.component.css']
})
export class CourseCreationfailureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
