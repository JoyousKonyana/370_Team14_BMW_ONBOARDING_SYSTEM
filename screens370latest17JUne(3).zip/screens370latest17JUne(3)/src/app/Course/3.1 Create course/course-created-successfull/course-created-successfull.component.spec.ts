import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseCreatedSuccessfullComponent } from './course-created-successfull.component';

describe('CourseCreatedSuccessfullComponent', () => {
  let component: CourseCreatedSuccessfullComponent;
  let fixture: ComponentFixture<CourseCreatedSuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseCreatedSuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseCreatedSuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
