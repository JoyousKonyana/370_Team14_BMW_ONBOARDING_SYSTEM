import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-created-successfull',
  templateUrl: './course-created-successfull.component.html',
  styleUrls: ['./course-created-successfull.component.css']
})
export class CourseCreatedSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
