import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseSuccessdialogueComponent } from './course-successdialogue.component';

describe('CourseSuccessdialogueComponent', () => {
  let component: CourseSuccessdialogueComponent;
  let fixture: ComponentFixture<CourseSuccessdialogueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseSuccessdialogueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseSuccessdialogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
