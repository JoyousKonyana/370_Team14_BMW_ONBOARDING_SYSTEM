import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-successdialogue',
  templateUrl: './course-successdialogue.component.html',
  styleUrls: ['./course-successdialogue.component.css']
})
export class CourseSuccessdialogueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
