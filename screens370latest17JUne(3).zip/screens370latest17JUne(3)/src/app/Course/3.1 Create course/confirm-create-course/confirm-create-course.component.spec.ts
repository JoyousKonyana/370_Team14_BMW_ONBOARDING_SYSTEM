import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmCreateCourseComponent } from './confirm-create-course.component';

describe('ConfirmCreateCourseComponent', () => {
  let component: ConfirmCreateCourseComponent;
  let fixture: ComponentFixture<ConfirmCreateCourseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmCreateCourseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmCreateCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
