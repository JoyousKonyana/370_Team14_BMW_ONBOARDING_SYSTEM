import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-create-course',
  templateUrl: './confirm-create-course.component.html',
  styleUrls: ['./confirm-create-course.component.css']
})
export class ConfirmCreateCourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
