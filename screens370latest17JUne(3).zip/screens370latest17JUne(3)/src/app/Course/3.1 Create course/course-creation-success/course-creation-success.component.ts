import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-creation-success',
  templateUrl: './course-creation-success.component.html',
  styleUrls: ['./course-creation-success.component.css']
})
export class CourseCreationSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
