import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseCreationSuccessComponent } from './course-creation-success.component';

describe('CourseCreationSuccessComponent', () => {
  let component: CourseCreationSuccessComponent;
  let fixture: ComponentFixture<CourseCreationSuccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseCreationSuccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseCreationSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
