import { ConfirmCreateCourseComponent } from './../confirm-create-course/confirm-create-course.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CourseCreationfailureComponent } from '../course-creationfailure/course-creationfailure.component';
import { CourseSuccessdialogueComponent } from '../course-successdialogue/course-successdialogue.component';
import { CourseCreationSuccessComponent } from '../course-creation-success/course-creation-success.component';
@Component({
  selector: 'app-create-course',
  templateUrl: './create-course.component.html',
  styleUrls: ['./create-course.component.css']
})
export class CreateCourseComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialog() {
    const dialogRef = this.dialog.open(CourseSuccessdialogueComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogfailure() {
    const dialogRef = this.dialog.open(CourseCreationfailureComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogConfirmCreateCourse() {
    const dialogRef = this.dialog.open(ConfirmCreateCourseComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogCreateCourseSuccess() {
    const dialogRef = this.dialog.open(CourseCreationSuccessComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

}



