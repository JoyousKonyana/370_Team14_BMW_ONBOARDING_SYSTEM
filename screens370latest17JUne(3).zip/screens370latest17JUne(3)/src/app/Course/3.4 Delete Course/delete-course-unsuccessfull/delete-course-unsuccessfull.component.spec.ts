import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteCourseUnsuccessfullComponent } from './delete-course-unsuccessfull.component';

describe('DeleteCourseUnsuccessfullComponent', () => {
  let component: DeleteCourseUnsuccessfullComponent;
  let fixture: ComponentFixture<DeleteCourseUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteCourseUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteCourseUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
