import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-course-unsuccessfull',
  templateUrl: './delete-course-unsuccessfull.component.html',
  styleUrls: ['./delete-course-unsuccessfull.component.css']
})
export class DeleteCourseUnsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
