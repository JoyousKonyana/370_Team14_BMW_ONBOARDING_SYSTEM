import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseDeletionSuccessfulComponent } from './course-deletion-successful.component';

describe('CourseDeletionSuccessfulComponent', () => {
  let component: CourseDeletionSuccessfulComponent;
  let fixture: ComponentFixture<CourseDeletionSuccessfulComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseDeletionSuccessfulComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseDeletionSuccessfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
