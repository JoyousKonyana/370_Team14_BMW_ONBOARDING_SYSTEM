import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-deletion-successful',
  templateUrl: './course-deletion-successful.component.html',
  styleUrls: ['./course-deletion-successful.component.css']
})
export class CourseDeletionSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
