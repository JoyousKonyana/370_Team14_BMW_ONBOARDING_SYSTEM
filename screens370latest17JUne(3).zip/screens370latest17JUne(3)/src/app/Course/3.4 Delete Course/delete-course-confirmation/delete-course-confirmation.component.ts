import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-course-confirmation',
  templateUrl: './delete-course-confirmation.component.html',
  styleUrls: ['./delete-course-confirmation.component.css']
})
export class DeleteCourseConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
