import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchAchievemenTypeCouldNotFindMatchComponent } from './search-achievemen-type-could-not-find-match.component';

describe('SearchAchievemenTypeCouldNotFindMatchComponent', () => {
  let component: SearchAchievemenTypeCouldNotFindMatchComponent;
  let fixture: ComponentFixture<SearchAchievemenTypeCouldNotFindMatchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchAchievemenTypeCouldNotFindMatchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchAchievemenTypeCouldNotFindMatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
