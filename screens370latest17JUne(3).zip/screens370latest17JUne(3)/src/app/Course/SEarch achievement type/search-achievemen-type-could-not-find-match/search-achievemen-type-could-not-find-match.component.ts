import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-achievemen-type-could-not-find-match',
  templateUrl: './search-achievemen-type-could-not-find-match.component.html',
  styleUrls: ['./search-achievemen-type-could-not-find-match.component.css']
})
export class SearchAchievemenTypeCouldNotFindMatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
