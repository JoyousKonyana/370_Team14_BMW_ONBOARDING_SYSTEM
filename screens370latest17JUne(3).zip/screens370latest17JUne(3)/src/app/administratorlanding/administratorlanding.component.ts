import { Component, OnInit } from '@angular/core';
import { SetQuizComponent } from '../Course/3.6 Set new quiz/set-quiz/set-quiz.component';
import { MatDialog } from '@angular/material/dialog';
import { CreateCourseComponent } from '../Course/3.1 Create course/create-course/create-course.component';
@Component({
  selector: 'app-administratorlanding',
  templateUrl: './administratorlanding.component.html',
  styleUrls: ['./administratorlanding.component.css']
})
export class AdministratorlandingComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogSetQuiz() {
    const dialogRef = this.dialog.open(SetQuizComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

  openDialogCreateCourse() {
    const dialogRef = this.dialog.open(CreateCourseComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
  }

}
