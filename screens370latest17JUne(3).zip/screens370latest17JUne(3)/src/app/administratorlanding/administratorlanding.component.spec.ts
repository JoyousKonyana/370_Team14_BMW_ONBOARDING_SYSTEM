import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministratorlandingComponent } from './administratorlanding.component';

describe('AdministratorlandingComponent', () => {
  let component: AdministratorlandingComponent;
  let fixture: ComponentFixture<AdministratorlandingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdministratorlandingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdministratorlandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
