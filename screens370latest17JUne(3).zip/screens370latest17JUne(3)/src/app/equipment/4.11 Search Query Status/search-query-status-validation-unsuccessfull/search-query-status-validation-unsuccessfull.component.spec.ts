import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchQueryStatusValidationUnsuccessfullComponent } from './search-query-status-validation-unsuccessfull.component';

describe('SearchQueryStatusValidationUnsuccessfullComponent', () => {
  let component: SearchQueryStatusValidationUnsuccessfullComponent;
  let fixture: ComponentFixture<SearchQueryStatusValidationUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchQueryStatusValidationUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchQueryStatusValidationUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
