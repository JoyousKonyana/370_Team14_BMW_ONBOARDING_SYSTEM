import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchQueryCriteriaRequiredComponent } from './search-query-criteria-required.component';

describe('SearchQueryCriteriaRequiredComponent', () => {
  let component: SearchQueryCriteriaRequiredComponent;
  let fixture: ComponentFixture<SearchQueryCriteriaRequiredComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchQueryCriteriaRequiredComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchQueryCriteriaRequiredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
