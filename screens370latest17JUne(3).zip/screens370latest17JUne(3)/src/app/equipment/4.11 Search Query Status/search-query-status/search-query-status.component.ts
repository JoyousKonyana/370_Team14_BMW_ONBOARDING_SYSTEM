
import { SearchQueryCriteriaRequiredComponent } from './../search-query-criteria-required/search-query-criteria-required.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { SearchQueryStatusValidationUnsuccessfullComponent } from '../search-query-status-validation-unsuccessfull/search-query-status-validation-unsuccessfull.component';


export interface QueryStatus {
 
  equipmentQueryStatusID: string;
  equipmentQuerydescription: string;
  status: string;



}

const ELEMENT_DATA: QueryStatus[] = [
  {equipmentQueryStatusID: '1', equipmentQuerydescription: 'Cracked laptop screen',status: 'Resolved'},
  {equipmentQueryStatusID: '2', equipmentQuerydescription: 'Broken charger',status: 'Unresolved'},
];
@Component({
  selector: 'app-search-query-status',
  templateUrl: './search-query-status.component.html',
  styleUrls: ['./search-query-status.component.css']
})
export class SearchQueryStatusComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {

    this.openDialogEditLessonOutcome();
  }


  displayedColumns: string[] = ['Equipment query status ID', 'Equipment query description', 'Status'
  ];
    dataSource = ELEMENT_DATA;

    openDialogEditLessonOutcome() {
      const dialogRef = this.dialog.open(SearchQueryStatusValidationUnsuccessfullComponent);

      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
      }
      });
    }
}
