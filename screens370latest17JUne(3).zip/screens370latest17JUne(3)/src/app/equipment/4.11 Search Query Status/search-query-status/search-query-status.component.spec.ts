import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchQueryStatusComponent } from './search-query-status.component';

describe('SearchQueryStatusComponent', () => {
  let component: SearchQueryStatusComponent;
  let fixture: ComponentFixture<SearchQueryStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchQueryStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchQueryStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
