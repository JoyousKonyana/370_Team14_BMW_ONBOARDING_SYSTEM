import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-push-notification',
  templateUrl: './push-notification.component.html',
  styleUrls: ['./push-notification.component.css']
})
export class PushNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
