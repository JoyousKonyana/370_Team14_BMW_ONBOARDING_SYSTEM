import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckEquipmentSuccessfullySavedComponent } from './check-equipment-successfully-saved.component';

describe('CheckEquipmentSuccessfullySavedComponent', () => {
  let component: CheckEquipmentSuccessfullySavedComponent;
  let fixture: ComponentFixture<CheckEquipmentSuccessfullySavedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckEquipmentSuccessfullySavedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckEquipmentSuccessfullySavedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
