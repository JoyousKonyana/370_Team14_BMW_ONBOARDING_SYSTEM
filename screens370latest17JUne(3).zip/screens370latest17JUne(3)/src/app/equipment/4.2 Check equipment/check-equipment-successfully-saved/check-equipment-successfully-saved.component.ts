import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-equipment-successfully-saved',
  templateUrl: './check-equipment-successfully-saved.component.html',
  styleUrls: ['./check-equipment-successfully-saved.component.css']
})
export class CheckEquipmentSuccessfullySavedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
