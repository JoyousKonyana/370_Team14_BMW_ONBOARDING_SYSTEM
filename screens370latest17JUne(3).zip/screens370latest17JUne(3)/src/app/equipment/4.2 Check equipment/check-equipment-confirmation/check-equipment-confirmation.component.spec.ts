import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckEquipmentConfirmationComponent } from './check-equipment-confirmation.component';

describe('CheckEquipmentConfirmationComponent', () => {
  let component: CheckEquipmentConfirmationComponent;
  let fixture: ComponentFixture<CheckEquipmentConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckEquipmentConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckEquipmentConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
