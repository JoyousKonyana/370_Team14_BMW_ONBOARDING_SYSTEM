import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-equipment-confirmation',
  templateUrl: './check-equipment-confirmation.component.html',
  styleUrls: ['./check-equipment-confirmation.component.css']
})
export class CheckEquipmentConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
