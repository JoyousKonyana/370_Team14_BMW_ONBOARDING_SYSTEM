import { CheckEquipmentConfirmationComponent } from './../check-equipment-confirmation/check-equipment-confirmation.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CheckEquipmentValidationComponent } from '../check-equipment-validation/check-equipment-validation.component';
import { PushNotificationComponent } from '../push-notification/push-notification.component';
@Component({
  selector: 'app-check-equipment',
  templateUrl: './check-equipment.component.html',
  styleUrls: ['./check-equipment.component.css']
})
export class CheckEquipmentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogcheckEquipmentConfirmation() {
    const dialogRef = this.dialog.open(CheckEquipmentConfirmationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogcheckEquipmentValidationError() {
    const dialogRef = this.dialog.open(CheckEquipmentValidationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogcheckEquipmentPushNOtification() {
    const dialogRef = this.dialog.open(PushNotificationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }
}
