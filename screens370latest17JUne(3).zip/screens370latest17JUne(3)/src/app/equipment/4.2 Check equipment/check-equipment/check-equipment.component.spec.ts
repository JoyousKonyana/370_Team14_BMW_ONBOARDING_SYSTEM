import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckEquipmentComponent } from './check-equipment.component';

describe('CheckEquipmentComponent', () => {
  let component: CheckEquipmentComponent;
  let fixture: ComponentFixture<CheckEquipmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckEquipmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckEquipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
