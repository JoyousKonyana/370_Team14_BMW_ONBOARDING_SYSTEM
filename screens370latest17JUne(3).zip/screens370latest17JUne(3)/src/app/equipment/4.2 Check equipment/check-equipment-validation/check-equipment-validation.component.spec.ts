import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckEquipmentValidationComponent } from './check-equipment-validation.component';

describe('CheckEquipmentValidationComponent', () => {
  let component: CheckEquipmentValidationComponent;
  let fixture: ComponentFixture<CheckEquipmentValidationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckEquipmentValidationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckEquipmentValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
