import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-equipment-validation',
  templateUrl: './check-equipment-validation.component.html',
  styleUrls: ['./check-equipment-validation.component.css']
})
export class CheckEquipmentValidationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
