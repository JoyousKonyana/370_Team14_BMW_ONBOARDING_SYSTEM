import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-equipment-confirmation',
  templateUrl: './delete-equipment-confirmation.component.html',
  styleUrls: ['./delete-equipment-confirmation.component.css']
})
export class DeleteEquipmentConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
