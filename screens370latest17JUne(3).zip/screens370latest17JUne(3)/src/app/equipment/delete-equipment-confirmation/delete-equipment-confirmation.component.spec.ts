import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteEquipmentConfirmationComponent } from './delete-equipment-confirmation.component';

describe('DeleteEquipmentConfirmationComponent', () => {
  let component: DeleteEquipmentConfirmationComponent;
  let fixture: ComponentFixture<DeleteEquipmentConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteEquipmentConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteEquipmentConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
