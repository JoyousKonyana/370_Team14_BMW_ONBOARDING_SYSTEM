import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EquipmentRetrievefailedComponent } from '../equipment-retrievefailed/equipment-retrievefailed.component';
export interface Equipment {
  equipmentId: string;
  equipmentType: string;
  equipmentTradeInDate: string;
  brand: string;
}

const ELEMENT_DATA: Equipment[] = [
  // {equipmentId: '1', equipmentType: 'YubiKey',equipmentTradeInDate: '17 May 2022',brand: 'Dell'},
  // {equipmentId: '2', equipmentType: 'Charger',equipmentTradeInDate: '16 Jan 2022',brand: 'Hp'},
  // {equipmentId: '3', equipmentType: 'Headsets',equipmentTradeInDate: '18 Jan 2022',brand: 'Mercer'}

];
@Component({
  selector: 'app-view-equipment',
  templateUrl: './view-equipment.component.html',
  styleUrls: ['./view-equipment.component.css']
})
export class ViewEquipmentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.openDialogEquipmentfailed();
  }
  displayedColumns: string[] = ['Equipment ID', 'Equipment Type','Equipment trade in date', 'Brand'];
  dataSource = ELEMENT_DATA;

  openDialogEquipmentfailed() {
    const dialogRef = this.dialog.open(EquipmentRetrievefailedComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

}
