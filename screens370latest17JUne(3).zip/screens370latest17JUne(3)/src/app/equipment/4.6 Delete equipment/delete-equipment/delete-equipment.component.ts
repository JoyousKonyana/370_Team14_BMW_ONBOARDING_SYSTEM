import { DeleteEquipmentConfirmationComponent } from '../../delete-equipment-confirmation/delete-equipment-confirmation.component';
import { EquipmentSuccessfullyDeletedComponent } from './../equipment-successfully-deleted/equipment-successfully-deleted.component';
import { DeleteEquipmentfailedComponent } from './../delete-equipmentfailed/delete-equipmentfailed.component';
import { EquipementSendEquipmentQueryComponent } from '../../4.7 Report Equipment query/equipement-send-equipment-query/equipement-send-equipment-query.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmdeleteEquipmentComponent } from '../confirmdelete-equipment/confirmdelete-equipment.component';
import { CheckEquipmentComponent } from '../../4.2 Check equipment/check-equipment/check-equipment.component';

export interface equipment {
 
  equipmentType: string;
  brand: string;
  equipmentDescription: string;
  serialNumber: string;


}

const ELEMENT_DATA: equipment[] = [
  {equipmentType: 'YubiKey', brand: 'Dell', equipmentDescription: 'Black', serialNumber:'12312132543123'},
  {equipmentType: 'Charger', brand: 'HP', equipmentDescription: 'Laptop charger', serialNumber:'123456789421'},

];
@Component({
  selector: 'app-delete-equipment',
  templateUrl: './delete-equipment.component.html',
  styleUrls: ['./delete-equipment.component.css']
})
export class DeleteEquipmentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  displayedColumns: string[] = ['Equipment type', 'Brand', 'Equipment Description', 'Serial number',
  'Edit', 'Delete'];
    dataSource = ELEMENT_DATA;

    openDialogConfirmDelete() {
      const dialogRef = this.dialog.open(ConfirmdeleteEquipmentComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }

    openDialogFailedToDeleteEquipment() {
      const dialogRef = this.dialog.open(DeleteEquipmentfailedComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }

    openDialogDeleteEquipmentSuccessfull() {
      const dialogRef = this.dialog.open(EquipmentSuccessfullyDeletedComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }

    openDialogDeleteEquipmentConfirmation() {
      const dialogRef = this.dialog.open(DeleteEquipmentConfirmationComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }
    openDialog() {
      const dialogRef = this.dialog.open(EquipementSendEquipmentQueryComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }


    openDialogCheck() {
      const dialogRef = this.dialog.open(CheckEquipmentComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }

}
