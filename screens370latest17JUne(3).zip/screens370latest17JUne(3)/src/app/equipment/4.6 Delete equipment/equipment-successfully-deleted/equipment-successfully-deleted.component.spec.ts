import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentSuccessfullyDeletedComponent } from './equipment-successfully-deleted.component';

describe('EquipmentSuccessfullyDeletedComponent', () => {
  let component: EquipmentSuccessfullyDeletedComponent;
  let fixture: ComponentFixture<EquipmentSuccessfullyDeletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipmentSuccessfullyDeletedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentSuccessfullyDeletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
