import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equipment-successfully-deleted',
  templateUrl: './equipment-successfully-deleted.component.html',
  styleUrls: ['./equipment-successfully-deleted.component.css']
})
export class EquipmentSuccessfullyDeletedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
