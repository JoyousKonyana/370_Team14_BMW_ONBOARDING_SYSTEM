import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmdeleteEquipmentComponent } from './confirmdelete-equipment.component';

describe('ConfirmdeleteEquipmentComponent', () => {
  let component: ConfirmdeleteEquipmentComponent;
  let fixture: ComponentFixture<ConfirmdeleteEquipmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmdeleteEquipmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmdeleteEquipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
