import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmdelete-equipment',
  templateUrl: './confirmdelete-equipment.component.html',
  styleUrls: ['./confirmdelete-equipment.component.css']
})
export class ConfirmdeleteEquipmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
