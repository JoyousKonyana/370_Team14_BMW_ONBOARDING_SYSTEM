import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteEquipmentfailedComponent } from './delete-equipmentfailed.component';

describe('DeleteEquipmentfailedComponent', () => {
  let component: DeleteEquipmentfailedComponent;
  let fixture: ComponentFixture<DeleteEquipmentfailedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteEquipmentfailedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteEquipmentfailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
