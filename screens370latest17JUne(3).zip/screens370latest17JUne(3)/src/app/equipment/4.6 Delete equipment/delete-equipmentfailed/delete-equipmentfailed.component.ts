import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-equipmentfailed',
  templateUrl: './delete-equipmentfailed.component.html',
  styleUrls: ['./delete-equipmentfailed.component.css']
})
export class DeleteEquipmentfailedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
