import { CheckEquipmentSuccessfullySavedComponent } from './../4.2 Check equipment/check-equipment-successfully-saved/check-equipment-successfully-saved.component';
import { CreateQueryStatusSuccessComponent } from './../4.8 Create query status/create-query-status-success/create-query-status-success.component';
import { CheckEquipmentComponent } from './../4.2 Check equipment/check-equipment/check-equipment.component';
import { lessoncontent } from './../../Course/3.22 Archive lesson content/archivelesson-content/archivelesson-content.component';
import { LessonOutcomeComponent } from './../../Course/3.18 Create lesson outcome/lesson-outcome/lesson-outcome.component';
import { CreateQuestionComponent } from './../../Course/3.9 Create question/create-question/create-question.component';
import { UpdateQuetsionBankComponent } from './../../Course/3.7 Update question Bank/update-quetsion-bank/update-quetsion-bank.component';
import { EditCourseComponent } from './../../Course/3.3 Edit course/edit-course/edit-course.component';
import { SendEquipmentdueForTradeInComponent } from './../4.12 Send equipment due for trade in/send-equipmentdue-for-trade-in/send-equipmentdue-for-trade-in.component';
import { EquipementSendEquipmentQueryComponent } from './../4.7 Report Equipment query/equipement-send-equipment-query/equipement-send-equipment-query.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';


import { RegisterEquipmentComponent } from '../4.1 Register Equipment/register-equipment/register-equipment.component';
import { CreateQuaryStatusComponent } from '../4.8 Create query status/create-quary-status/create-quary-status.component';
import { ResolveQueryComponent } from '../4.10 Resolve query/resolve-query/resolve-query.component';
import { SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent } from '../4.12 Send equipment due for trade in/send-equipment-due-for-trade-in-status-validation-unsuccessfull/send-equipment-due-for-trade-in-status-validation-unsuccessfull.component';
import { CreateCourseComponent } from 'src/app/Course/3.1 Create course/create-course/create-course.component';
import { SetQuizComponent } from 'src/app/Course/3.6 Set new quiz/set-quiz/set-quiz.component';
import { UpdateQuestionComponent } from 'src/app/Course/3.11 Update Question/update-question/update-question.component';
import { CreateAchievementTypeComponent } from 'src/app/Course/3.14 Create Achievement type/create-achievement-type/create-achievement-type.component';
import { UpdateAchievementTypeComponent } from 'src/app/Course/3.15 Update Achievement type/update-achievement-type/update-achievement-type.component';
import { EditLessonOutcomeComponent } from 'src/app/Course/3.19 Update lesson outcome/edit-lesson-outcome/edit-lesson-outcome.component';
import { ReportEquipmentQuerySuccessComponent } from '../4.7 Report Equipment query/report-equipment-query-success/report-equipment-query-success.component';
import { ConfirmRegistrationComponent } from '../4.1 Register Equipment/confirm-registration/confirm-registration.component';
import { DisplayOnboarderInformationfailedComponent } from 'src/app/Admin/2.1Register Employee/2.2 VIew onboarder/VIew onbaorder full information/display-onboarder-informationfailed/display-onboarder-informationfailed.component';
@Component({
  selector: 'app-viewpages',
  templateUrl: './viewpages.component.html',
  styleUrls: ['./viewpages.component.css']
})
export class ViewpagesComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.openDialogTradeInStatusRetrivalfailed();
  }


  openDialogTradeInStatusRetrivalfailed() {
    const dialogRef = this.dialog.open(DisplayOnboarderInformationfailedComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

}
