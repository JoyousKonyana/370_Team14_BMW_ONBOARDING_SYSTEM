import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewpagesComponent } from './viewpages.component';

describe('ViewpagesComponent', () => {
  let component: ViewpagesComponent;
  let fixture: ComponentFixture<ViewpagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewpagesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewpagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
