import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendEquipmentforTradeInDEscriptionREquiredComponent } from './send-equipmentfor-trade-in-description-required.component';

describe('SendEquipmentforTradeInDEscriptionREquiredComponent', () => {
  let component: SendEquipmentforTradeInDEscriptionREquiredComponent;
  let fixture: ComponentFixture<SendEquipmentforTradeInDEscriptionREquiredComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SendEquipmentforTradeInDEscriptionREquiredComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SendEquipmentforTradeInDEscriptionREquiredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
