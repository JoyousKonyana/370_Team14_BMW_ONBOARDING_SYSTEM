import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-equipmentfor-trade-in-description-required',
  templateUrl: './send-equipmentfor-trade-in-description-required.component.html',
  styleUrls: ['./send-equipmentfor-trade-in-description-required.component.css']
})
export class SendEquipmentforTradeInDEscriptionREquiredComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
