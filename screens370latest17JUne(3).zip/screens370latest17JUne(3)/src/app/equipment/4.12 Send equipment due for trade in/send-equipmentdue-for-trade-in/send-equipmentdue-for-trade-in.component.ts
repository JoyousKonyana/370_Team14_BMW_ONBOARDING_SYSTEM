import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent } from '../send-equipment-due-for-trade-in-status-validation-unsuccessfull/send-equipment-due-for-trade-in-status-validation-unsuccessfull.component';
import { SendEquipmentDueforTradeinConfirmationComponent } from '../send-equipment-duefor-tradein-confirmation/send-equipment-duefor-tradein-confirmation.component';
import { SendEquipmentforTradeInDEscriptionREquiredComponent } from '../send-equipmentfor-trade-in-description-required/send-equipmentfor-trade-in-description-required.component';
@Component({
  selector: 'app-send-equipmentdue-for-trade-in',
  templateUrl: './send-equipmentdue-for-trade-in.component.html',
  styleUrls: ['./send-equipmentdue-for-trade-in.component.css']
})
export class SendEquipmentdueForTradeInComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    // this.openDialogSendEquipment();
  }

  
  openDialogSendEquipment() {
    const dialogRef = this.dialog.open(SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }
}
