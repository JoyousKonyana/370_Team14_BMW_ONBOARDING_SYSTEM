import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendEquipmentdueForTradeInComponent } from './send-equipmentdue-for-trade-in.component';

describe('SendEquipmentdueForTradeInComponent', () => {
  let component: SendEquipmentdueForTradeInComponent;
  let fixture: ComponentFixture<SendEquipmentdueForTradeInComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SendEquipmentdueForTradeInComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SendEquipmentdueForTradeInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
