import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-equipment-due-for-trade-in-status-validation-unsuccessfull',
  templateUrl: './send-equipment-due-for-trade-in-status-validation-unsuccessfull.component.html',
  styleUrls: ['./send-equipment-due-for-trade-in-status-validation-unsuccessfull.component.css']
})
export class SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
