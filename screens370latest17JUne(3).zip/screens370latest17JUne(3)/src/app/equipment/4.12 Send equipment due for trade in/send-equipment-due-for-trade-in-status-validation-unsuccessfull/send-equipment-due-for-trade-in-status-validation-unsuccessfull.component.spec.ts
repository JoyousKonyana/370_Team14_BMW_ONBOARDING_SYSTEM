import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent } from './send-equipment-due-for-trade-in-status-validation-unsuccessfull.component';

describe('SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent', () => {
  let component: SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent;
  let fixture: ComponentFixture<SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
