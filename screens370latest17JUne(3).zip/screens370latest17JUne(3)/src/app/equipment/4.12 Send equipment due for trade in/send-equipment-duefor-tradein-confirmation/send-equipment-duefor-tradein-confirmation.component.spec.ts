import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendEquipmentDueforTradeinConfirmationComponent } from './send-equipment-duefor-tradein-confirmation.component';

describe('SendEquipmentDueforTradeinConfirmationComponent', () => {
  let component: SendEquipmentDueforTradeinConfirmationComponent;
  let fixture: ComponentFixture<SendEquipmentDueforTradeinConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SendEquipmentDueforTradeinConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SendEquipmentDueforTradeinConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
