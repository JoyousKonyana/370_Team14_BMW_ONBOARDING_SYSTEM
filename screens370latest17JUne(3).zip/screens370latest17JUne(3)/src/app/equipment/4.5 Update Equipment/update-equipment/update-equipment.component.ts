import { EquipmentUpdateSuccessfullyComponent } from './../equipment-update-successfully/equipment-update-successfully.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { UpdateEquipmentConfirmationComponent } from '../update-equipment-confirmation/update-equipment-confirmation.component';
import { UpdateEquipmentVAlidationComponent } from '../update-equipment-validation/update-equipment-validation.component';
@Component({
  selector: 'app-update-equipment',
  templateUrl: './update-equipment.component.html',
  styleUrls: ['./update-equipment.component.css']
})
export class UpdateEquipmentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }
  openDialog() {
    const dialogRef = this.dialog.open(UpdateEquipmentVAlidationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogEquipmentUPdateConfirmation() {
    const dialogRef = this.dialog.open(UpdateEquipmentConfirmationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogEquipmentUPdatedsuccessfull() {
    const dialogRef = this.dialog.open(EquipmentUpdateSuccessfullyComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }


  openDialogEquipmentUPdatedVAlidationerror() {
    const dialogRef = this.dialog.open(UpdateEquipmentComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }
}
