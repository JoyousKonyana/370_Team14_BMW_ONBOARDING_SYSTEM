import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equipment-update-successfully',
  templateUrl: './equipment-update-successfully.component.html',
  styleUrls: ['./equipment-update-successfully.component.css']
})
export class EquipmentUpdateSuccessfullyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
