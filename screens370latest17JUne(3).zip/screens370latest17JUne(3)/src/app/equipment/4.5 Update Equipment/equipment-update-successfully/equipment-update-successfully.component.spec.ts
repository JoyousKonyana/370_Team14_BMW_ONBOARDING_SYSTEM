import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentUpdateSuccessfullyComponent } from './equipment-update-successfully.component';

describe('EquipmentUpdateSuccessfullyComponent', () => {
  let component: EquipmentUpdateSuccessfullyComponent;
  let fixture: ComponentFixture<EquipmentUpdateSuccessfullyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipmentUpdateSuccessfullyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentUpdateSuccessfullyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
