import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-equipment-confirmation',
  templateUrl: './update-equipment-confirmation.component.html',
  styleUrls: ['./update-equipment-confirmation.component.css']
})
export class UpdateEquipmentConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
