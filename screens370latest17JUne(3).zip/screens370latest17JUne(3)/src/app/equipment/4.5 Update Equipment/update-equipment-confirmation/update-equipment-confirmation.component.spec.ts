import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateEquipmentConfirmationComponent } from './update-equipment-confirmation.component';

describe('UpdateEquipmentConfirmationComponent', () => {
  let component: UpdateEquipmentConfirmationComponent;
  let fixture: ComponentFixture<UpdateEquipmentConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateEquipmentConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateEquipmentConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
