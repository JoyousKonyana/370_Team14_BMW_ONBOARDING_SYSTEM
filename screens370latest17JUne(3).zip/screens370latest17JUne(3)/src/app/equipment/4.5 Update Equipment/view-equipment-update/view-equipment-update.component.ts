import { Component, OnInit } from '@angular/core';
export interface equipment {
 
  equipmentType: string;
  brand: string;
  equipmentDescription: string;
  serialNumber: string;


}

const ELEMENT_DATA: equipment[] = [
  {equipmentType: 'YubiKey', brand: 'Dell', equipmentDescription: 'Black', serialNumber:'12312132543123'},
  {equipmentType: 'Charger', brand: 'HP', equipmentDescription: 'Laptop charger', serialNumber:'123456789421'},

];
@Component({
  selector: 'app-view-equipment-update',
  templateUrl: './view-equipment-update.component.html',
  styleUrls: ['./view-equipment-update.component.css']
})
export class ViewEquipmentUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  displayedColumns: string[] = ['Equipment type', 'Brand', 'Equipment Description', 'Serial number',
  'Edit', 'Delete'];
    dataSource = ELEMENT_DATA;

}
