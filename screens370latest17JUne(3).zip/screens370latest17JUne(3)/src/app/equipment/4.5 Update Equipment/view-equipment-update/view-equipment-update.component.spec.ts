import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEquipmentUpdateComponent } from './view-equipment-update.component';

describe('ViewEquipmentUpdateComponent', () => {
  let component: ViewEquipmentUpdateComponent;
  let fixture: ComponentFixture<ViewEquipmentUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewEquipmentUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewEquipmentUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
