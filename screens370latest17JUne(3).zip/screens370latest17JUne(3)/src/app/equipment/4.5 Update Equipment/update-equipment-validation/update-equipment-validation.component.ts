import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-equipment-validation',
  templateUrl: './update-equipment-validation.component.html',
  styleUrls: ['./update-equipment-validation.component.css']
})
export class UpdateEquipmentVAlidationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
