import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateEquipmentVAlidationComponent } from './update-equipment-validation.component';

describe('UpdateEquipmentVAlidationComponent', () => {
  let component: UpdateEquipmentVAlidationComponent;
  let fixture: ComponentFixture<UpdateEquipmentVAlidationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateEquipmentVAlidationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateEquipmentVAlidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
