import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportEquipmentQuerySuccessComponent } from './report-equipment-query-success.component';

describe('ReportEquipmentQuerySuccessComponent', () => {
  let component: ReportEquipmentQuerySuccessComponent;
  let fixture: ComponentFixture<ReportEquipmentQuerySuccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportEquipmentQuerySuccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportEquipmentQuerySuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
