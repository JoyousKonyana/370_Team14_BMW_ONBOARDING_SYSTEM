import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-equipment-query-success',
  templateUrl: './report-equipment-query-success.component.html',
  styleUrls: ['./report-equipment-query-success.component.css']
})
export class ReportEquipmentQuerySuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
