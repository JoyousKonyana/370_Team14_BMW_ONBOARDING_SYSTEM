import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FailedToCreateQueryComponent } from './failed-to-create-query.component';

describe('FailedToCreateQueryComponent', () => {
  let component: FailedToCreateQueryComponent;
  let fixture: ComponentFixture<FailedToCreateQueryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FailedToCreateQueryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FailedToCreateQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
