import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-failed-to-create-query',
  templateUrl: './failed-to-create-query.component.html',
  styleUrls: ['./failed-to-create-query.component.css']
})
export class FailedToCreateQueryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
