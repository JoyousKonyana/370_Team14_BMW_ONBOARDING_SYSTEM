import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-required',
  templateUrl: './confirm-required.component.html',
  styleUrls: ['./confirm-required.component.css']
})
export class ConfirmRequiredComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
