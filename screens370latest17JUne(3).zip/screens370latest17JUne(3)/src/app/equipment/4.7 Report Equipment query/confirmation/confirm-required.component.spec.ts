import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmRequiredComponent } from './confirm-required.component';

describe('ConfirmRequiredComponent', () => {
  let component: ConfirmRequiredComponent;
  let fixture: ComponentFixture<ConfirmRequiredComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmRequiredComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmRequiredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
