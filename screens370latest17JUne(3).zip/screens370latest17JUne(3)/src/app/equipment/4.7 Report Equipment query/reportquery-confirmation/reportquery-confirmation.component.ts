import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportquery-confirmation',
  templateUrl: './reportquery-confirmation.component.html',
  styleUrls: ['./reportquery-confirmation.component.css']
})
export class ReportqueryConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
