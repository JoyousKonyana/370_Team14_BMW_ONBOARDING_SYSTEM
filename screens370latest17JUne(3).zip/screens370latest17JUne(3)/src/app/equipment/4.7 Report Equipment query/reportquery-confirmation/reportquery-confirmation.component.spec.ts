import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportqueryConfirmationComponent } from './reportquery-confirmation.component';

describe('ReportqueryConfirmationComponent', () => {
  let component: ReportqueryConfirmationComponent;
  let fixture: ComponentFixture<ReportqueryConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportqueryConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportqueryConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
