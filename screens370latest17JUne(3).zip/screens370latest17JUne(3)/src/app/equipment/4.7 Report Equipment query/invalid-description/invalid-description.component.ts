import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-description',
  templateUrl: './invalid-description.component.html',
  styleUrls: ['./invalid-description.component.css']
})
export class InvalidDescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
