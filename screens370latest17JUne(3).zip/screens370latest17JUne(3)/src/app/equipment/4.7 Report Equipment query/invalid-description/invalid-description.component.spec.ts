import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvalidDescriptionComponent } from './invalid-description.component';

describe('InvalidDescriptionComponent', () => {
  let component: InvalidDescriptionComponent;
  let fixture: ComponentFixture<InvalidDescriptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvalidDescriptionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvalidDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
