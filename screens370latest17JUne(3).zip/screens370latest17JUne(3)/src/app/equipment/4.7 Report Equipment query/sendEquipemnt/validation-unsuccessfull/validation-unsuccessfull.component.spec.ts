import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidationUnsuccessfullComponent } from './validation-unsuccessfull.component';

describe('ValidationUnsuccessfullComponent', () => {
  let component: ValidationUnsuccessfullComponent;
  let fixture: ComponentFixture<ValidationUnsuccessfullComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ValidationUnsuccessfullComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidationUnsuccessfullComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
