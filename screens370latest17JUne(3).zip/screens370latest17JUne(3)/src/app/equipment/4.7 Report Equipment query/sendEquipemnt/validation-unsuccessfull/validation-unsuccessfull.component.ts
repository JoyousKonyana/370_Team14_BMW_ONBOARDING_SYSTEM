import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-validation-unsuccessfull',
  templateUrl: './validation-unsuccessfull.component.html',
  styleUrls: ['./validation-unsuccessfull.component.css']
})
export class ValidationUnsuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
