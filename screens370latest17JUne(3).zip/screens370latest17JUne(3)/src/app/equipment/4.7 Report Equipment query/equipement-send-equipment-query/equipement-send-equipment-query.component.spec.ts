import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipementSendEquipmentQueryComponent } from './equipement-send-equipment-query.component';

describe('EquipementSendEquipmentQueryComponent', () => {
  let component: EquipementSendEquipmentQueryComponent;
  let fixture: ComponentFixture<EquipementSendEquipmentQueryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipementSendEquipmentQueryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipementSendEquipmentQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
