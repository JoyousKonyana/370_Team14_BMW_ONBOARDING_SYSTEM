import { RegisterEquipmentValidationErrorComponent } from './../../4.1 Register Equipment/register-equipment-validation-error/register-equipment-validation-error.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ReportqueryConfirmationComponent } from '../reportquery-confirmation/reportquery-confirmation.component';
import { FailedToCreateQueryComponent } from '../failed-to-create-query/failed-to-create-query.component';
import { InvalidDescriptionComponent } from '../invalid-description/invalid-description.component';

@Component({
  selector: 'app-equipement-send-equipment-query',
  templateUrl: './equipement-send-equipment-query.component.html',
  styleUrls: ['./equipement-send-equipment-query.component.css']
})
export class EquipementSendEquipmentQueryComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }


  openDialogTradeInStatusRetrivalfailed() {
    const dialogRef = this.dialog.open(ReportqueryConfirmationComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogfailedToCreateQuery() {
    const dialogRef = this.dialog.open(FailedToCreateQueryComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

  openDialogInvalidDescription() {
    const dialogRef = this.dialog.open(InvalidDescriptionComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

}
