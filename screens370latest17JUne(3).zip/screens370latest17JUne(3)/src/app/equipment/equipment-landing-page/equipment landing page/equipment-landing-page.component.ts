import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equipment-landing-page',
  templateUrl: './equipment-landing-page.component.html',
  styleUrls: ['./equipment-landing-page.component.css']
})
export class EquipmentLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
