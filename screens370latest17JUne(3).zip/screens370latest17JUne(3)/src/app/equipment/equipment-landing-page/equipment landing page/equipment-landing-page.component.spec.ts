import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentLandingPageComponent } from './equipment-landing-page.component';

describe('EquipmentLandingPageComponent', () => {
  let component: EquipmentLandingPageComponent;
  let fixture: ComponentFixture<EquipmentLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipmentLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
