import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentSuccessfyllySavedComponent } from './equipment-successfylly-saved.component';

describe('EquipmentSuccessfyllySavedComponent', () => {
  let component: EquipmentSuccessfyllySavedComponent;
  let fixture: ComponentFixture<EquipmentSuccessfyllySavedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipmentSuccessfyllySavedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentSuccessfyllySavedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
