import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equipment-successfylly-saved',
  templateUrl: './equipment-successfylly-saved.component.html',
  styleUrls: ['./equipment-successfylly-saved.component.css']
})
export class EquipmentSuccessfyllySavedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
