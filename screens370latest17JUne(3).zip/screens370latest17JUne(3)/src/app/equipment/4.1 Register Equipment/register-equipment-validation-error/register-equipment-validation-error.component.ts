import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-equipment-validation-error',
  templateUrl: './register-equipment-validation-error.component.html',
  styleUrls: ['./register-equipment-validation-error.component.css']
})
export class RegisterEquipmentValidationErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
