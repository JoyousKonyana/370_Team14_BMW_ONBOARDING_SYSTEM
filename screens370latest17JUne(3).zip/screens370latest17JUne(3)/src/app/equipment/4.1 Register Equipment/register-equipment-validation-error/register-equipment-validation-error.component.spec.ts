import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterEquipmentValidationErrorComponent } from './register-equipment-validation-error.component';

describe('RegisterEquipmentValidationErrorComponent', () => {
  let component: RegisterEquipmentValidationErrorComponent;
  let fixture: ComponentFixture<RegisterEquipmentValidationErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterEquipmentValidationErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterEquipmentValidationErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
