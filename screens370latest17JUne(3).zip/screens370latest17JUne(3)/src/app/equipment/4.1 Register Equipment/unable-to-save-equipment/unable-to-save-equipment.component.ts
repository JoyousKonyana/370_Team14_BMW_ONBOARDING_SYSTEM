import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unable-to-save-equipment',
  templateUrl: './unable-to-save-equipment.component.html',
  styleUrls: ['./unable-to-save-equipment.component.css']
})
export class UnableToSAveEquipmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
