import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnableToSAveEquipmentComponent } from './unable-to-save-equipment.component';

describe('UnableToSAveEquipmentComponent', () => {
  let component: UnableToSAveEquipmentComponent;
  let fixture: ComponentFixture<UnableToSAveEquipmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnableToSAveEquipmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnableToSAveEquipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
