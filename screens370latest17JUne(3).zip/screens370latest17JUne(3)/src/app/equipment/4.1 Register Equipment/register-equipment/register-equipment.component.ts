import { EquipmentSuccessfyllySavedComponent } from './../equipment-successfylly-saved/equipment-successfylly-saved.component';
import { RegisterEquipmentValidationErrorComponent } from './../register-equipment-validation-error/register-equipment-validation-error.component';
import { RegisterEquipmentConfirmComponent } from './../register-equipment-confirm/register-equipment-confirm.component';

import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';


import { UnableToSAveEquipmentComponent } from '../unable-to-save-equipment/unable-to-save-equipment.component';
import { ConfirmRegistrationComponent } from '../confirm-registration/confirm-registration.component';
@Component({
  selector: 'app-register-equipment',
  templateUrl: './register-equipment.component.html',
  styleUrls: ['./register-equipment.component.css']
})
export class RegisterEquipmentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    // this.openDialogSuccessfullySaved();
    
  }
  openDialogConfirmREgisterEquipment() {
    const dialogRef = this.dialog.open(RegisterEquipmentConfirmComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){
    }
    });
}

openDialogConfirmREgisterEquipment2() {
  const dialogRef = this.dialog.open(ConfirmRegistrationComponent);

  dialogRef.afterClosed().subscribe(result => {
    if(!result === false){
  }
  });
}



openDialogSuccessfullySaved() {
  const dialogRef = this.dialog.open(EquipmentSuccessfyllySavedComponent);

  dialogRef.afterClosed().subscribe(result => {
    if(!result === false){
  }
  });
}


openDialogequipmentVAlidationError() {
  const dialogRef = this.dialog.open(RegisterEquipmentValidationErrorComponent);

  dialogRef.afterClosed().subscribe(result => {
    if(!result === false){
  }
  });
}


openDialogValidationError() {
  const dialogRef = this.dialog.open(RegisterEquipmentValidationErrorComponent);

  dialogRef.afterClosed().subscribe(result => {
    if(!result === false){
  }
  });
}


openDialogUnableToSave() {
  const dialogRef = this.dialog.open(UnableToSAveEquipmentComponent);

  dialogRef.afterClosed().subscribe(result => {
    if(!result === false){
  }
  });
}

}
