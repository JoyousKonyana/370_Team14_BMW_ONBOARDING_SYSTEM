import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterEquipmentConfirmComponent } from './register-equipment-confirm.component';

describe('RegisterEquipmentConfirmComponent', () => {
  let component: RegisterEquipmentConfirmComponent;
  let fixture: ComponentFixture<RegisterEquipmentConfirmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterEquipmentConfirmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterEquipmentConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
