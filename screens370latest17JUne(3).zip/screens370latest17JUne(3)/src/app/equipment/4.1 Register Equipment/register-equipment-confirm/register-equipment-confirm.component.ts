import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-equipment-confirm',
  templateUrl: './register-equipment-confirm.component.html',
  styleUrls: ['./register-equipment-confirm.component.css']
})
export class RegisterEquipmentConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
