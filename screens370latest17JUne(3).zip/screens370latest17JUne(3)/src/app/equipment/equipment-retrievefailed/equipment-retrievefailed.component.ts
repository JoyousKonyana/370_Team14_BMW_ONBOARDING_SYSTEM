import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-equipment-retrievefailed',
  templateUrl: './equipment-retrievefailed.component.html',
  styleUrls: ['./equipment-retrievefailed.component.css']
})
export class EquipmentRetrievefailedComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  
}
