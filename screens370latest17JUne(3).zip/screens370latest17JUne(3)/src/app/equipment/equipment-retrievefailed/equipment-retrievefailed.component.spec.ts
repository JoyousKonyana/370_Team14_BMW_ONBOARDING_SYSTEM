import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentRetrievefailedComponent } from './equipment-retrievefailed.component';

describe('EquipmentRetrievefailedComponent', () => {
  let component: EquipmentRetrievefailedComponent;
  let fixture: ComponentFixture<EquipmentRetrievefailedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipmentRetrievefailedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentRetrievefailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
