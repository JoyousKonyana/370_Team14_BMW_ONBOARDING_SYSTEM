import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { QueryStatusNotFoundComponent } from '../query-status-not-found/query-status-not-found.component';
export interface TradeInStatus {
  equipmentQueryStatusID: string;
  equipmentQueryStatusDescription: string;
  Status: string;
 
}

const ELEMENT_DATA: TradeInStatus[] = [
//  {equipmentQueryStatusID: '1', equipmentQueryStatusDescription: 'Cracked laptop screen', Status:'Resolved'},
//  {equipmentQueryStatusID: '2', equipmentQueryStatusDescription: 'Broken', Status:'UnResolved'}


];
@Component({
  selector: 'app-view-query-status',
  templateUrl: './view-query-status.component.html',
  styleUrls: ['./view-query-status.component.css']
})
export class ViewQueryStatusComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.openDialogTradeInStatusRetrivalfailed();
  }
  displayedColumns: string[] = ['Equipment query status ID', 'Equipment query description','Status'];
  dataSource = ELEMENT_DATA;
  openDialogTradeInStatusRetrivalfailed() {
    const dialogRef = this.dialog.open(QueryStatusNotFoundComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

}
