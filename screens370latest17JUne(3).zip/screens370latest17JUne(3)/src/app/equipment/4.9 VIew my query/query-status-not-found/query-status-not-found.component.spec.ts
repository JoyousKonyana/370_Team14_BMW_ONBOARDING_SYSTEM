import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QueryStatusNotFoundComponent } from './query-status-not-found.component';

describe('QueryStatusNotFoundComponent', () => {
  let component: QueryStatusNotFoundComponent;
  let fixture: ComponentFixture<QueryStatusNotFoundComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QueryStatusNotFoundComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QueryStatusNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
