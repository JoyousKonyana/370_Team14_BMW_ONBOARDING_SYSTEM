import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-query-status-not-found',
  templateUrl: './query-status-not-found.component.html',
  styleUrls: ['./query-status-not-found.component.css']
})
export class QueryStatusNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
