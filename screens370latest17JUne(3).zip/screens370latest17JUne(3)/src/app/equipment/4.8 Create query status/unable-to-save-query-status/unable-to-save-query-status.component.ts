import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unable-to-save-query-status',
  templateUrl: './unable-to-save-query-status.component.html',
  styleUrls: ['./unable-to-save-query-status.component.css']
})
export class UnableToSAveQueryStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
