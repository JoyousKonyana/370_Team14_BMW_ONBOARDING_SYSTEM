import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnableToSAveQueryStatusComponent } from './unable-to-save-query-status.component';

describe('UnableToSAveQueryStatusComponent', () => {
  let component: UnableToSAveQueryStatusComponent;
  let fixture: ComponentFixture<UnableToSAveQueryStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnableToSAveQueryStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnableToSAveQueryStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
