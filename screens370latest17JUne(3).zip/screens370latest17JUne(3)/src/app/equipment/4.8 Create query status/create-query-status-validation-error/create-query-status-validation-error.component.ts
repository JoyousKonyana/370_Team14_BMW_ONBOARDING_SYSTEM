import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-query-status-validation-error',
  templateUrl: './create-query-status-validation-error.component.html',
  styleUrls: ['./create-query-status-validation-error.component.css']
})
export class CreateQueryStatusVAlidationErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
