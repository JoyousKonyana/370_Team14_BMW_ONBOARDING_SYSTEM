import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateQueryStatusVAlidationErrorComponent } from './create-query-status-validation-error.component';

describe('CreateQueryStatusVAlidationErrorComponent', () => {
  let component: CreateQueryStatusVAlidationErrorComponent;
  let fixture: ComponentFixture<CreateQueryStatusVAlidationErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateQueryStatusVAlidationErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateQueryStatusVAlidationErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
