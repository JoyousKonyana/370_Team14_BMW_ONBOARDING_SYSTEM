import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateQuaryStatusComponent } from './create-quary-status.component';

describe('CreateQuaryStatusComponent', () => {
  let component: CreateQuaryStatusComponent;
  let fixture: ComponentFixture<CreateQuaryStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateQuaryStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateQuaryStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
