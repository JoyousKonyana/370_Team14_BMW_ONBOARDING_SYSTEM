import { UnableToSAveQueryStatusComponent } from './../unable-to-save-query-status/unable-to-save-query-status.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmCreateStatusComponent } from '../confirm-create-status/confirm-create-status.component';
import { CreateQueryStatusVAlidationErrorComponent } from '../create-query-status-validation-error/create-query-status-validation-error.component';
@Component({
  selector: 'app-create-quary-status',
  templateUrl: './create-quary-status.component.html',
  styleUrls: ['./create-quary-status.component.css']
})
export class CreateQuaryStatusComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogTradeInStatusRetrivalfailed() {
    const dialogRef = this.dialog.open(CreateQueryStatusVAlidationErrorComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

}
