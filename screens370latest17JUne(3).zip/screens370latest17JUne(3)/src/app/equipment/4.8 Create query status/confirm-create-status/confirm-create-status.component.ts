import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-confirm-create-status',
  templateUrl: './confirm-create-status.component.html',
  styleUrls: ['./confirm-create-status.component.css']
})
export class ConfirmCreateStatusComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  
}
