import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmCreateStatusComponent } from './confirm-create-status.component';

describe('ConfirmCreateStatusComponent', () => {
  let component: ConfirmCreateStatusComponent;
  let fixture: ComponentFixture<ConfirmCreateStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmCreateStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmCreateStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
