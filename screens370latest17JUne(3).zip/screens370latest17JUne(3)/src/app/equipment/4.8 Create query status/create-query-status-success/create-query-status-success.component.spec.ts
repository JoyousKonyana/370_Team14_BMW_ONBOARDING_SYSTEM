import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateQueryStatusSuccessComponent } from './create-query-status-success.component';

describe('CreateQueryStatusSuccessComponent', () => {
  let component: CreateQueryStatusSuccessComponent;
  let fixture: ComponentFixture<CreateQueryStatusSuccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateQueryStatusSuccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateQueryStatusSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
