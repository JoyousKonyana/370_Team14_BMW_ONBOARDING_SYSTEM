import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-query-status-success',
  templateUrl: './create-query-status-success.component.html',
  styleUrls: ['./create-query-status-success.component.css']
})
export class CreateQueryStatusSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
