// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-send-equipment-duefor-tradein-confirmation',
//   templateUrl: './send-equipment-duefor-tradein-confirmation.component.html',
//   styleUrls: ['./send-equipment-duefor-tradein-confirmation.component.css']
// })
// export class SendEquipmentDueforTradeinConfirmationComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
