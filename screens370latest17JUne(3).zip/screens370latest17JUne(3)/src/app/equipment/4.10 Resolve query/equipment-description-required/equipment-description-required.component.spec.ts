import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentDescriptionRequiredComponent } from './equipment-description-required.component';

describe('EquipmentDescriptionRequiredComponent', () => {
  let component: EquipmentDescriptionRequiredComponent;
  let fixture: ComponentFixture<EquipmentDescriptionRequiredComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipmentDescriptionRequiredComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentDescriptionRequiredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
