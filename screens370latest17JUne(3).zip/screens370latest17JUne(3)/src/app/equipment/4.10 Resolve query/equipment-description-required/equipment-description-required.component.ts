import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equipment-description-required',
  templateUrl: './equipment-description-required.component.html',
  styleUrls: ['./equipment-description-required.component.css']
})
export class EquipmentDescriptionRequiredComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
