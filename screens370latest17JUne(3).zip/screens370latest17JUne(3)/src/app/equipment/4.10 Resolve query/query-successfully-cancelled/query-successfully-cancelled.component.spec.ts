import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuerySuccessfullyCAncelledComponent } from './query-successfully-cancelled.component';

describe('QuerySuccessfullyCAncelledComponent', () => {
  let component: QuerySuccessfullyCAncelledComponent;
  let fixture: ComponentFixture<QuerySuccessfullyCAncelledComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuerySuccessfullyCAncelledComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuerySuccessfullyCAncelledComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
