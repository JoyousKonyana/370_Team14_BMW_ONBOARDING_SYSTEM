import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-query-successfully-cancelled',
  templateUrl: './query-successfully-cancelled.component.html',
  styleUrls: ['./query-successfully-cancelled.component.css']
})
export class QuerySuccessfullyCAncelledComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
