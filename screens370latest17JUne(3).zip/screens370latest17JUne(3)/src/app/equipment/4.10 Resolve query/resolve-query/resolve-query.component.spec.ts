import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResolveQueryComponent } from './resolve-query.component';

describe('ResolveQueryComponent', () => {
  let component: ResolveQueryComponent;
  let fixture: ComponentFixture<ResolveQueryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResolveQueryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResolveQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
