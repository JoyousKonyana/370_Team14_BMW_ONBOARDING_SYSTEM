import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EquipmentDescriptionRequiredComponent } from '../equipment-description-required/equipment-description-required.component';
import { QuerySuccessfullyCAncelledComponent } from '../query-successfully-cancelled/query-successfully-cancelled.component';
@Component({
  selector: 'app-resolve-query',
  templateUrl: './resolve-query.component.html',
  styleUrls: ['./resolve-query.component.css']
})
export class ResolveQueryComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogEquipementDEscriptionRequired() {
    const dialogRef = this.dialog.open(QuerySuccessfullyCAncelledComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }

}
