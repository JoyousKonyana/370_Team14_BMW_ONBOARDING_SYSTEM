import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assigned-equipment-not-found',
  templateUrl: './assigned-equipment-not-found.component.html',
  styleUrls: ['./assigned-equipment-not-found.component.css']
})
export class AssignedEquipmentNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
