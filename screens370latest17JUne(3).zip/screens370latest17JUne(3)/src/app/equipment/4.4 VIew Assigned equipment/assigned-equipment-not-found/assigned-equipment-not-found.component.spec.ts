import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignedEquipmentNotFoundComponent } from './assigned-equipment-not-found.component';

describe('AssignedEquipmentNotFoundComponent', () => {
  let component: AssignedEquipmentNotFoundComponent;
  let fixture: ComponentFixture<AssignedEquipmentNotFoundComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignedEquipmentNotFoundComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignedEquipmentNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
