import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAssignedEquipmentComponent } from './view-assigned-equipment.component';

describe('ViewAssignedEquipmentComponent', () => {
  let component: ViewAssignedEquipmentComponent;
  let fixture: ComponentFixture<ViewAssignedEquipmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAssignedEquipmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAssignedEquipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
