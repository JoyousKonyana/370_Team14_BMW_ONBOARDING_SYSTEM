import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AssignedEquipmentNotFoundComponent } from '../assigned-equipment-not-found/assigned-equipment-not-found.component';


export interface AssignedEquipment {
 
  equipmentID: string;
  onboarderID: string;
  checkInDate: string;
  checkInDEscription: string;
  checkOutDAte: string;


}

const ELEMENT_DATA: AssignedEquipment[] = [
  // {equipmentID: '1', onboarderID: '9789076543012', checkInDate: '17 January 2021', checkInDEscription: 'Excellent',checkOutDAte: '17 December 2023'},
  // {equipmentID: '2', onboarderID: '9789076543013', checkInDate: '19 January 2021', checkInDEscription: 'Excellent',checkOutDAte: '20 December 2023'}

];
@Component({
  selector: 'app-view-assigned-equipment',
  templateUrl: './view-assigned-equipment.component.html',
  styleUrls: ['./view-assigned-equipment.component.css']
})
export class ViewAssignedEquipmentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {

    this.openDialogAssignedEquipentNotFound();
  }


  displayedColumns: string[] = ['Equipment ID', 'Onboader ID', 'Checkindate', 'Check in Description', 'Check out Date'
  ];
    dataSource = ELEMENT_DATA;

    openDialogAssignedEquipentNotFound() {
      const dialogRef = this.dialog.open(AssignedEquipmentNotFoundComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }
}
