import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-description-required',
  templateUrl: './description-required.component.html',
  styleUrls: ['./description-required.component.css']
})
export class DescriptionRequiredComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
