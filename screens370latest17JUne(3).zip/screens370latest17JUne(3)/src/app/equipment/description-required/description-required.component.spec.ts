import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DescriptionRequiredComponent } from './description-required.component';

describe('DescriptionRequiredComponent', () => {
  let component: DescriptionRequiredComponent;
  let fixture: ComponentFixture<DescriptionRequiredComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DescriptionRequiredComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DescriptionRequiredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
