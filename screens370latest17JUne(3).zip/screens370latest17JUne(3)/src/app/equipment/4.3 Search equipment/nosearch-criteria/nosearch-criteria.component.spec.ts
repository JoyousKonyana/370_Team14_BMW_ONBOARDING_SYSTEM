import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NosearchCriteriaComponent } from './nosearch-criteria.component';

describe('NosearchCriteriaComponent', () => {
  let component: NosearchCriteriaComponent;
  let fixture: ComponentFixture<NosearchCriteriaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NosearchCriteriaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NosearchCriteriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
