import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nosearch-criteria',
  templateUrl: './nosearch-criteria.component.html',
  styleUrls: ['./nosearch-criteria.component.css']
})
export class NosearchCriteriaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
