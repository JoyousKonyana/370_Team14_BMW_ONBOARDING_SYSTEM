import { FailedToRetrieveResultsComponent } from './../failed-to-retrieve-results/failed-to-retrieve-results.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { NosearchCriteriaComponent } from '../nosearch-criteria/nosearch-criteria.component';

export interface equipment {
 
  equipmentType: string;
  brand: string;
  equipmentDescription: string;
  serialNumber: string;


}

const ELEMENT_DATA: equipment[] = [
  {equipmentType: 'YubiKey', brand: 'Dell', equipmentDescription: 'Black', serialNumber:'12312132543123'},
  {equipmentType: 'Charger', brand: 'HP', equipmentDescription: 'Laptop charger', serialNumber:'123456789421'},

];
@Component({
  selector: 'app-search-equipment',
  templateUrl: './search-equipment.component.html',
  styleUrls: ['./search-equipment.component.css']
})
export class SearchEquipmentComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.openDialogcheckEquipmentPushNOtification();
  }


  displayedColumns: string[] = ['Equipment type', 'Brand', 'Equipment Description', 'Serial number',
  ];
    dataSource = ELEMENT_DATA;
    openDialogcheckEquipmentPushNOtification() {
      const dialogRef = this.dialog.open(NosearchCriteriaComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        if(!result === false){
  
  
      }
      });
    }
}
