import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-failed-to-retrieve-results',
  templateUrl: './failed-to-retrieve-results.component.html',
  styleUrls: ['./failed-to-retrieve-results.component.css']
})
export class FailedToRetrieveResultsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
