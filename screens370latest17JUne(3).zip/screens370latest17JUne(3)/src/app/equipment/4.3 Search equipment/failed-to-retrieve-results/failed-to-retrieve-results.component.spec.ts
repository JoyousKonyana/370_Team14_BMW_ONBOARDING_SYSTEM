import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FailedToRetrieveResultsComponent } from './failed-to-retrieve-results.component';

describe('FailedToRetrieveResultsComponent', () => {
  let component: FailedToRetrieveResultsComponent;
  let fixture: ComponentFixture<FailedToRetrieveResultsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FailedToRetrieveResultsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FailedToRetrieveResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
