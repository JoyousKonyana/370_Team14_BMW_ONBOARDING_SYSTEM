// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-search-query-criteria-required',
//   templateUrl: './search-query-criteria-required.component.html',
//   styleUrls: ['./search-query-criteria-required.component.css']
// })
// export class SearchQueryCriteriaRequiredComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
