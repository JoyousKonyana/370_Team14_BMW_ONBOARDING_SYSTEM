// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-search-query-status-validation-unsuccessfull',
//   templateUrl: './search-query-status-validation-unsuccessfull.component.html',
//   styleUrls: ['./search-query-status-validation-unsuccessfull.component.css']
// })
// export class SearchQueryStatusValidationUnsuccessfullComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
