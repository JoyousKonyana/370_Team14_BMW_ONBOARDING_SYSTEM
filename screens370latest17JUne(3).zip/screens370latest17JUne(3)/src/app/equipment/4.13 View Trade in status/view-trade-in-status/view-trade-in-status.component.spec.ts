import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewTradeInStatusComponent } from './view-trade-in-status.component';

describe('ViewTradeInStatusComponent', () => {
  let component: ViewTradeInStatusComponent;
  let fixture: ComponentFixture<ViewTradeInStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewTradeInStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTradeInStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
