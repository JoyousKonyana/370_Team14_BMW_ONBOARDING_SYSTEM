import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TradeInStatusRetrivalFAiledComponent } from '../trade-in-status-retrival-failed/trade-in-status-retrival-failed.component';
export interface TradeInStatus {
  tradeInStatusId: string;
  tradeinSatus: string;
  tradeInStatusDescription: string;
 
}

const ELEMENT_DATA: TradeInStatus[] = [
  // {tradeInStatusId: '1', tradeinSatus: 'Traded in', tradeInStatusDescription: 'Good condition'},
  // {tradeInStatusId: '2', tradeinSatus: 'Not traded in', tradeInStatusDescription: 'Poor condition'},
  // {tradeInStatusId: '3', tradeinSatus: 'Traded in', tradeInStatusDescription: 'Excellent condition'}


];

@Component({
  selector: 'app-view-trade-in-status',
  templateUrl: './view-trade-in-status.component.html',
  styleUrls: ['./view-trade-in-status.component.css']
})
export class ViewTradeInStatusComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.openDialogTradeInStatusRetrivalfailed()
  }
  displayedColumns: string[] = ['Trade in status ID', 'Trade in status','Trade in status description'];
  dataSource = ELEMENT_DATA;

  openDialogTradeInStatusRetrivalfailed() {
    const dialogRef = this.dialog.open(TradeInStatusRetrivalFAiledComponent);

    dialogRef.afterClosed().subscribe(result => {
      if(!result === false){


    }
    });
  }
}
