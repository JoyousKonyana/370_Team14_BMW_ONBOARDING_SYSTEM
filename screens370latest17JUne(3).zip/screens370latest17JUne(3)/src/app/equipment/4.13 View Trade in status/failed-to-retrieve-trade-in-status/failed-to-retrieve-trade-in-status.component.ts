import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-failed-to-retrieve-trade-in-status',
  templateUrl: './failed-to-retrieve-trade-in-status.component.html',
  styleUrls: ['./failed-to-retrieve-trade-in-status.component.css']
})
export class FailedToRetrieveTradeInStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
