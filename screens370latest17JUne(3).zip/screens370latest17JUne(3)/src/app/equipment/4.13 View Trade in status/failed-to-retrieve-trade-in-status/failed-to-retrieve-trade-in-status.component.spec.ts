import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FailedToRetrieveTradeInStatusComponent } from './failed-to-retrieve-trade-in-status.component';

describe('FailedToRetrieveTradeInStatusComponent', () => {
  let component: FailedToRetrieveTradeInStatusComponent;
  let fixture: ComponentFixture<FailedToRetrieveTradeInStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FailedToRetrieveTradeInStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FailedToRetrieveTradeInStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
