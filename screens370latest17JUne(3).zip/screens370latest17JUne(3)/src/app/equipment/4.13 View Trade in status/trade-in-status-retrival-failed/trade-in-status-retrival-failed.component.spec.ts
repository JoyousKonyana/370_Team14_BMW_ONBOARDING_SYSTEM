import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TradeInStatusRetrivalFAiledComponent } from './trade-in-status-retrival-failed.component';

describe('TradeInStatusRetrivalFAiledComponent', () => {
  let component: TradeInStatusRetrivalFAiledComponent;
  let fixture: ComponentFixture<TradeInStatusRetrivalFAiledComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TradeInStatusRetrivalFAiledComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TradeInStatusRetrivalFAiledComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
