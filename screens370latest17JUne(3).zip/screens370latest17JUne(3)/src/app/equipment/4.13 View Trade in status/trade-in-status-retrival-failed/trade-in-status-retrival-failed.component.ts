import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trade-in-status-retrival-failed',
  templateUrl: './trade-in-status-retrival-failed.component.html',
  styleUrls: ['./trade-in-status-retrival-failed.component.css']
})
export class TradeInStatusRetrivalFAiledComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
