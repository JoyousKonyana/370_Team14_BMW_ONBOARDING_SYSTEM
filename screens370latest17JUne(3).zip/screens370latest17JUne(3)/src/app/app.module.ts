import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdministratorlandingComponent } from './administratorlanding/administratorlanding.component';
import {MatCardModule} from '@angular/material/card';
import { CreateCourseComponent } from './Course/3.1 Create course/create-course/create-course.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { CourseSuccessdialogueComponent } from './Course/3.1 Create course/course-successdialogue/course-successdialogue.component';
import {MatDialogModule} from '@angular/material/dialog';
import { CourseCreationfailureComponent } from './Course/3.1 Create course/course-creationfailure/course-creationfailure.component';
import { CourseCreationSuccessComponent } from './Course/3.1 Create course/course-creation-success/course-creation-success.component';
import { CreateQuestionComponent } from './Course/3.9 Create question/create-question/create-question.component';
import {MatSelectModule} from '@angular/material/select';
import {MatRadioModule} from '@angular/material/radio';
import { ConfirmCreateQuestionComponent } from './Course/3.9 Create question/confirm-create-question/confirm-create-question.component';
import { QuestionCreationFailureComponent } from './Course/3.9 Create question/question-creation-failure/question-creation-failure.component';
import { QuestionCreationSuccessComponent } from './Course/3.9 Create question/question-creation-success/question-creation-success.component';
import { CancelQuestionCreationComponent } from './Course/3.9 Create question/cancel-question-creation/cancel-question-creation.component';
import { ViewCoursesAdminComponent } from './Course/3.2 View course/view-courses-admin/view-courses-admin.component';
import {MatTableModule} from '@angular/material/table';
import { ViewCourseErrorComponent } from './Course/3.2 View course/view-course-error/view-course-error.component';
import { UpdateCourseComponent } from './Course/3.3 Edit course/update-course/update-course.component';
import { CourseCreatedSuccessfullComponent } from './Course/3.1 Create course/course-created-successfull/course-created-successfull.component';
import { CourseUpdateSuccessfullComponent } from './Course/3.3 Edit course/course-update-successfull/course-update-successfull.component';
import { CourseUpdateFailureComponent } from './Course/3.3 Edit course/course-update-failure/course-update-failure.component';
import { ConfirmUpdateCourseComponent } from './Course/3.3 Edit course/confirm-update-course/confirm-update-course.component';
import { DeleteCourseConfirmationComponent } from './Course/3.4 Delete Course/delete-course-confirmation/delete-course-confirmation.component';
import { CourseDeletionSuccessfulComponent } from './Course/3.4 Delete Course/course-deletion-successful/course-deletion-successful.component';
import { ViewQuestionBankComponent } from './Course/3.8 View Question Bank/view-question-bank/view-question-bank.component';
import { ViewQuestionBankErrorComponent } from './Course/3.8 View Question Bank/view-question-bank-error/view-question-bank-error.component';
import { SetQuizComponent } from './Course/3.6 Set new quiz/set-quiz/set-quiz.component';
import { SetQuizConfimationComponent } from './Course/3.6 Set new quiz/set-quiz-confimation/set-quiz-confimation.component';
import { SetQuizUnsuccessfulComponent } from './Course/3.6 Set new quiz/set-quiz-unsuccessful/set-quiz-unsuccessful.component';
import { SetQuizSuccessfulComponent } from './Course/3.6 Set new quiz/set-quiz-successful/set-quiz-successful.component';
import { LessonOutcomeComponent } from './Course/3.18 Create lesson outcome/lesson-outcome/lesson-outcome.component';
import { ComfirmLessonOutcomeCreationComponent } from './Course/3.18 Create lesson outcome/comfirm-lesson-outcome-creation/comfirm-lesson-outcome-creation.component';
import { LessonoutcomeCreationfailureComponent } from './Course/3.18 Create lesson outcome/lessonoutcome-creationfailure/lessonoutcome-creationfailure.component';
import { ViewLessonOutcomeComponent } from './Course/view-lesson-outcome/view-lesson-outcome.component';
import { EditLessonOutcomeComponent } from './Course/3.19 Update lesson outcome/edit-lesson-outcome/edit-lesson-outcome.component';
import { LessonOutcomeUpdateSuccessfullComponent } from './Course/3.19 Update lesson outcome/lesson-outcome-update-successfull/lesson-outcome-update-successfull.component';
import { LessonoutcomeUpdateSuccessfullComponent } from './Course/3.19 Update lesson outcome/lessonoutcome-update-successfull/lessonoutcome-update-successfull.component';
import { DeleteLessonoutcomeConfirmationComponent } from './Course/3.20 Delete lesson outcome/delete-lessonoutcome-confirmation/delete-lessonoutcome-confirmation.component';
import { ViewArchivedLessonContentComponent } from './Course/3.21 VIew Archived lesson content/view-archived-lesson-content/view-archived-lesson-content.component';
import { DeleteArchivedLessonContentConfimationComponent } from './Course/3.23 Unarchive lesson content/delete-archived-lesson-content-confimation/delete-archived-lesson-content-confimation.component';
import { DeleteArchivedLessonContentSuccessfullyComponent } from './Course/3.23 Unarchive lesson content/delete-archived-lesson-content-successfully/delete-archived-lesson-content-successfully.component';
import { DeletelessonContentUnsuccessfullComponent } from './deletelesson-content-unsuccessfull/deletelesson-content-unsuccessfull.component';
import { ArchivelessonContentComponent } from './Course/3.22 Archive lesson content/archivelesson-content/archivelesson-content.component';
import { ComfirmLessonContentArchiveComponent } from './Course/3.22 Archive lesson content/comfirm-lesson-content-archive/comfirm-lesson-content-archive.component';
import { LessonContentAchirvedSuccefullyComponent } from './Course/3.22 Archive lesson content/lesson-content-achirved-succefully/lesson-content-achirved-succefully.component';
import { LessonUnsuccessfullyArchivedComponent } from './Course/3.22 Archive lesson content/lesson-unsuccessfully-archived/lesson-unsuccessfully-archived.component';
import { EquipmentLandingPageComponent } from './equipment/equipment-landing-page/equipment landing page/equipment-landing-page.component';
// import { QuestionCreatedSuccessfulComponent } from './question-created-successful/question-created-successful.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/compiler';
import {
  MatIconModule} from '@angular/material/icon';

  import {MatToolbarModule} from '@angular/material/toolbar';
  import {MatListModule} from '@angular/material/list'
import { MatDividerModule } from '@angular/material/divider';
import { RegisteronBoarderComponent } from './Admin/2.1Register Employee/2.1  Register Employee/registeron-boarder/registeron-boarder.component';
import { EditOnboarderComponent } from './Admin/2.1Register Employee/2.3 Edit onboarder/edit-onboarder/edit-onboarder.component';
import { OnboarderSuccessfullyEditedComponent } from './Admin/2.1Register Employee/2.3 Edit onboarder/onboarder-successfully-edited/onboarder-successfully-edited.component';
import { ConfirmOnboarderChangesComponent } from './Admin/2.1Register Employee/2.3 Edit onboarder/confirm-onboarder-changes/confirm-onboarder-changes.component';
import { ViewOnboardersComponent } from './Admin/2.1Register Employee/2.2 VIew onboarder/2.2 View onboarder/view-onboarders/view-onboarders.component';
import { ConfirmDeleteOnboarderComponent } from './Admin/2.1Register Employee/2.4 Delete onboarder/confirm-delete-onboarder/confirm-delete-onboarder.component';
import { OnboarderSuccesfullydeletedComponent } from './Admin/2.1Register Employee/2.4 Delete onboarder/onboarder-succesfullydeleted/onboarder-succesfullydeleted.component';
import { ConfirmRegisterEmployeeComponent } from './Admin/2.1Register Employee/2.1  Register Employee/confirm-register-employee/confirm-register-employee.component';
import { EmployeeRegistrationSuccessComponent } from './Admin/2.1Register Employee/2.1  Register Employee/employee-registration-success/employee-registration-success.component';
import { RegisterEquipmentComponent } from './equipment/4.1 Register Equipment/register-equipment/register-equipment.component';
import { ViewEquipmentComponent } from './equipment/view-equipment/view-equipment.component';
import { EquipmentRetrievefailedComponent } from './equipment/equipment-retrievefailed/equipment-retrievefailed.component';
import { ViewTradeInStatusComponent } from './equipment/4.13 View Trade in status/view-trade-in-status/view-trade-in-status.component';
import { TradeInStatusRetrivalFAiledComponent } from './equipment/4.13 View Trade in status/trade-in-status-retrival-failed/trade-in-status-retrival-failed.component';
import { SendEquipmentdueForTradeInComponent } from './equipment/4.12 Send equipment due for trade in/send-equipmentdue-for-trade-in/send-equipmentdue-for-trade-in.component';
import { ViewpagesComponent } from './equipment/viewpages/viewpages.component';
// import { ConfirmRequiredComponent } from './equipment/sendEquipmentquiry/confirm-required/confirm-required.component';
import { ValidationUnsuccessfullComponent } from './equipment/4.7 Report Equipment query/sendEquipemnt/validation-unsuccessfull/validation-unsuccessfull.component';
import { RouterModule } from '@angular/router';
import { DescriptionRequiredComponent } from './equipment/description-required/description-required.component';
import { ResolveQueryComponent } from './equipment/4.10 Resolve query/resolve-query/resolve-query.component';
import { EquipmentDescriptionRequiredComponent } from './equipment/4.10 Resolve query/equipment-description-required/equipment-description-required.component';
import { QuerySuccessfullyCAncelledComponent } from './equipment/4.10 Resolve query/query-successfully-cancelled/query-successfully-cancelled.component';
import { ViewQueryStatusComponent } from './equipment/4.9 VIew my query/view-query-status/view-query-status.component';
import { QueryStatusNotFoundComponent } from './equipment/4.9 VIew my query/query-status-not-found/query-status-not-found.component';
import { CreateQuaryStatusComponent } from './equipment/4.8 Create query status/create-quary-status/create-quary-status.component';
import { CreateQueryStatusVAlidationErrorComponent } from './equipment/4.8 Create query status/create-query-status-validation-error/create-query-status-validation-error.component';
import { ConfirmCreateStatusComponent } from './equipment/4.8 Create query status/confirm-create-status/confirm-create-status.component';
import { UnableToSAveQueryStatusComponent } from './equipment/4.8 Create query status/unable-to-save-query-status/unable-to-save-query-status.component';
import { FailedToCreateQueryComponent } from './equipment/4.7 Report Equipment query/failed-to-create-query/failed-to-create-query.component';
import { InvalidDescriptionComponent } from './equipment/4.7 Report Equipment query/invalid-description/invalid-description.component';
import { UpdateEquipmentComponent } from './equipment/4.5 Update Equipment/update-equipment/update-equipment.component';

import { UpdateEquipmentConfirmationComponent } from './equipment/4.5 Update Equipment/update-equipment-confirmation/update-equipment-confirmation.component';
import { UpdateEquipmentVAlidationComponent } from './equipment/4.5 Update Equipment/update-equipment-validation/update-equipment-validation.component';
import { ViewEquipmentUpdateComponent } from './equipment/4.5 Update Equipment/view-equipment-update/view-equipment-update.component';
import { EquipmentSuccessfyllySavedComponent } from './equipment/4.1 Register Equipment/equipment-successfylly-saved/equipment-successfylly-saved.component';
import { RegisterEquipmentConfirmComponent } from './equipment/4.1 Register Equipment/register-equipment-confirm/register-equipment-confirm.component';
import { DeleteEquipmentComponent } from './equipment/4.6 Delete equipment/delete-equipment/delete-equipment.component';
import { ConfirmdeleteEquipmentComponent } from './equipment/4.6 Delete equipment/confirmdelete-equipment/confirmdelete-equipment.component';
import { DeleteEquipmentfailedComponent } from './equipment/4.6 Delete equipment/delete-equipmentfailed/delete-equipmentfailed.component';
import { RegisterEquipmentValidationErrorComponent } from './equipment/4.1 Register Equipment/register-equipment-validation-error/register-equipment-validation-error.component';
import { UnableToSAveEquipmentComponent } from './equipment/4.1 Register Equipment/unable-to-save-equipment/unable-to-save-equipment.component';
import { EquipementSendEquipmentQueryComponent } from './equipment/4.7 Report Equipment query/equipement-send-equipment-query/equipement-send-equipment-query.component';
import { CheckEquipmentComponent } from './equipment/4.2 Check equipment/check-equipment/check-equipment.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { CheckEquipmentValidationComponent } from './equipment/4.2 Check equipment/check-equipment-validation/check-equipment-validation.component';
import { CheckEquipmentConfirmationComponent } from './equipment/4.2 Check equipment/check-equipment-confirmation/check-equipment-confirmation.component';
import { PushNotificationComponent } from './equipment/4.2 Check equipment/push-notification/push-notification.component';
import { SearchEquipmentComponent } from './equipment/4.3 Search equipment/search-equipment/search-equipment.component';
import { NosearchCriteriaComponent } from './equipment/4.3 Search equipment/nosearch-criteria/nosearch-criteria.component';
import { FailedToRetrieveResultsComponent } from './equipment/4.3 Search equipment/failed-to-retrieve-results/failed-to-retrieve-results.component';
import { ViewAssignedEquipmentComponent } from './equipment/4.4 VIew Assigned equipment/view-assigned-equipment/view-assigned-equipment.component';
import { AssignedEquipmentNotFoundComponent } from './equipment/4.4 VIew Assigned equipment/assigned-equipment-not-found/assigned-equipment-not-found.component';
import { EquipmentUpdateSuccessfullyComponent } from './equipment/4.5 Update Equipment/equipment-update-successfully/equipment-update-successfully.component';
import { EquipmentSuccessfullyDeletedComponent } from './equipment/4.6 Delete equipment/equipment-successfully-deleted/equipment-successfully-deleted.component';
import { SearchQueryStatusComponent } from './equipment/4.11 Search Query Status/search-query-status/search-query-status.component';
import { SearchQueryCriteriaRequiredComponent } from './equipment/4.11 Search Query Status/search-query-criteria-required/search-query-criteria-required.component';
import { SearchQueryStatusValidationUnsuccessfullComponent } from './equipment/4.11 Search Query Status/search-query-status-validation-unsuccessfull/search-query-status-validation-unsuccessfull.component';
import { SendEquipmentforTradeInDEscriptionREquiredComponent } from './equipment/4.12 Send equipment due for trade in/send-equipmentfor-trade-in-description-required/send-equipmentfor-trade-in-description-required.component';
import { SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent } from './equipment/4.12 Send equipment due for trade in/send-equipment-due-for-trade-in-status-validation-unsuccessfull/send-equipment-due-for-trade-in-status-validation-unsuccessfull.component';
import { FailedToRetrieveTradeInStatusComponent } from './equipment/4.13 View Trade in status/failed-to-retrieve-trade-in-status/failed-to-retrieve-trade-in-status.component';
import { SendEquipmentDueforTradeinConfirmationComponent } from './equipment/4.12 Send equipment due for trade in/send-equipment-duefor-tradein-confirmation/send-equipment-duefor-tradein-confirmation.component';
import { UpdateQuetsionBankComponent } from './Course/3.7 Update question Bank/update-quetsion-bank/update-quetsion-bank.component';
import { UpdateQuestionBankConfirmComponent } from './Course/3.7 Update question Bank/update-question-bank-confirm/update-question-bank-confirm.component';
import { QuestionBAnkSuccessfullyUpdatedComponent } from './Course/3.7 Update question Bank/question-bank-successfully-updated/question-bank-successfully-updated.component';
import { UpdateQuestionBankErrorComponent } from './Course/3.7 Update question Bank/update-question-bank-error/update-question-bank-error.component';
import { ViewQuestionBankQuestionsComponent } from './Course/3.10  Delete question/view-question-bank-questions/view-question-bank-questions.component';
import { DeleteQuestionConfirmComponent } from './Course/3.10  Delete question/delete-question-confirm/delete-question-confirm.component';
import { QuestionDeletedSuccessfullyComponent } from './Course/3.10  Delete question/question-deleted-successfully/question-deleted-successfully.component';
import { QuestionDeleteUnsuccessfullComponent } from './Course/3.10  Delete question/question-delete-unsuccessfull/question-delete-unsuccessfull.component';
import { UpdateQuestionComponent } from './Course/3.11 Update Question/update-question/update-question.component';
import { ConfirmUpdateQuestionComponent } from './Course/3.11 Update Question/confirm-update-question/confirm-update-question.component';
import { QuestionSuccefullyUpdatedComponent } from './Course/3.11 Update Question/question-succefully-updated/question-succefully-updated.component';
import { UpdateQuestionErrorComponent } from './Course/3.11 Update Question/update-question-error/update-question-error.component';
import { CreateAchievementTypeComponent } from './Course/3.14 Create Achievement type/create-achievement-type/create-achievement-type.component';
import { AchievementTypeCreatedSuccessfullComponent } from './Course/3.14 Create Achievement type/achievement-type-created-successfull/achievement-type-created-successfull.component';
import { UpdateAchievementTypeComponent } from './Course/3.15 Update Achievement type/update-achievement-type/update-achievement-type.component';
import { AchievementTYpeUpdateSuccessfullComponent } from './Course/3.15 Update Achievement type/achievement-type-update-successfull/achievement-type-update-successfull.component';
import { AchievementTypeupdateUnsuccessfullComponent } from './Course/3.15 Update Achievement type/achievement-typeupdate-unsuccessfull/achievement-typeupdate-unsuccessfull.component';
import { ViewAchivementTypesComponent } from './Course/view-achivement-types/view-achivement-types.component';
import { DeleteAchievementTypeComponent } from './Course/3.16 Delete Achievemnt type/delete-achievement-type/delete-achievement-type.component';
import { AchievementTypeDeletionSuccessfullComponent } from './Course/3.16 Delete Achievemnt type/achievement-type-deletion-successfull/achievement-type-deletion-successfull.component';
import { AchievementTypeDeletionUnsuccessfullComponent } from './Course/3.16 Delete Achievemnt type/achievement-type-deletion-unsuccessfull/achievement-type-deletion-unsuccessfull.component';
import { LessonOutcomeCreationSuccessComponent } from './Course/3.18 Create lesson outcome/lesson-outcome-creation-success/lesson-outcome-creation-success.component';
import { ConfirmEditLessonOutcomeComponent } from './Course/3.19 Update lesson outcome/confirm-edit-lesson-outcome/confirm-edit-lesson-outcome.component';
import { DeleteLessonoutcomeSuccessfullComponent } from './Course/3.20 Delete lesson outcome/delete-lessonoutcome-successfull/delete-lessonoutcome-successfull.component';
import { CreateAchievementTypeConfirmationComponent } from './Course/3.14 Create Achievement type/create-achievement-type-confirmation/create-achievement-type-confirmation.component';
import { CreateAchievementTypeUnsuccessfullComponent } from './Course/3.14 Create Achievement type/create-achievement-type-unsuccessfull/create-achievement-type-unsuccessfull.component';
import { ConfirmAchievementTypeUpdateComponent } from './Course/3.15 Update Achievement type/confirm-achievement-type-update/confirm-achievement-type-update.component';
import { EditCourseComponent } from './Course/3.3 Edit course/edit-course/edit-course.component';
import { ConfirmRegistrationComponent } from './equipment/4.1 Register Equipment/confirm-registration/confirm-registration.component';
import { DeleteEquipmentConfirmationComponent } from './equipment/delete-equipment-confirmation/delete-equipment-confirmation.component';
import { ReportqueryConfirmationComponent } from './equipment/4.7 Report Equipment query/reportquery-confirmation/reportquery-confirmation.component';
import { ConfirmCreateCourseComponent } from './Course/3.1 Create course/confirm-create-course/confirm-create-course.component';
import { DeleteCourseUnsuccessfullComponent } from './Course/3.4 Delete Course/delete-course-unsuccessfull/delete-course-unsuccessfull.component';
import { QuestionDeletionErrorComponent } from './Course/3.10  Delete question/question-deletion-error/question-deletion-error.component';
import { AchievementTYpeunsuccessfullyCreatedComponent } from './Course/achievement-typeunsuccessfully-created/achievement-typeunsuccessfully-created.component';
import { ViewLessonOutcomeVIewErroComponent } from './Course/view-lesson-outcome-view-erro/view-lesson-outcome-view-erro.component';
import { LessonOutcomeUpdateunsuccessfullComponent } from './Course/3.19 Update lesson outcome/lesson-outcome-updateunsuccessfull/lesson-outcome-updateunsuccessfull.component';
import { LessonOutcomeDeletionunsuccesfullComponent } from './Course/3.20 Delete lesson outcome/lesson-outcome-deletionunsuccesfull/lesson-outcome-deletionunsuccesfull.component';
import { ViewArchivedLessonContentErrorComponent } from './Course/3.21 VIew Archived lesson content/view-archived-lesson-content-error/view-archived-lesson-content-error.component';
import { UnArchiveFailedComponent } from './Course/3.23 Unarchive lesson content/un-archive-failed/un-archive-failed.component';
import { SearchARcivedLessonContentCouldnotFindMatchComponent } from './Course/3.24 Search archived lesson content/search-arcived-lesson-content-couldnot-find-match/search-arcived-lesson-content-couldnot-find-match.component';
import { SearchAchievemenTypeCouldNotFindMatchComponent } from './Course/SEarch achievement type/search-achievemen-type-could-not-find-match/search-achievemen-type-could-not-find-match.component';
import { ViewAchievementTypeErrorComponent } from './Course/view-achievement-type-error/view-achievement-type-error.component';
import { GenerateCourseProgressComponent } from './Course/3.13 Generate progress report/Generate course progress/generate-course-progress/generate-course-progress.component';
import { AdminLanding2Component } from './Course/admin-landing2/admin-landing2.component';
import { ReportScreenComponent } from './Course/3.13 Generate progress report/report-screen/report-screen.component';
import { ReportsScreenComponent } from './Course/3.13 Generate progress report/reports-screen/reports-screen.component';
import { ViewOnboarderComponent } from './Admin/2.1Register Employee/2.2 VIew onboarder/VIew onbaorder full information/view-onboarder/view-onboarder.component';
import { DisplayOnboarderInformationfailedComponent } from './Admin/2.1Register Employee/2.2 VIew onboarder/VIew onbaorder full information/display-onboarder-informationfailed/display-onboarder-informationfailed.component';
import { Editonboarder2Component } from './Admin/2.1Register Employee/2.3 Edit onboarder/editonboarder2/editonboarder2.component';
import { EquipmentAssignedSuccessfullyComponent } from './Admin/2.1Register Employee/2.5 Assign Equipment/equipment-assigned-successfully/equipment-assigned-successfully.component';
import { EquipmentAssignedUnsuccessfullComponent } from './Admin/2.1Register Employee/2.5 Assign Equipment/equipment-assigned-unsuccessfull/equipment-assigned-unsuccessfull.component';
import { AssignedEquipmentComponent } from './Admin/2.1Register Employee/2.5 Assign Equipment/assigned-equipment/assigned-equipment.component';
import { SearchOnboarderFailureComponent } from './Admin/2.1Register Employee/Search onboarder/search-onboarder-failure/search-onboarder-failure.component';
import { OnboarderProgressReportComponent } from './Course/3.13 Generate progress report/onboarder-progress-report/onboarder-progress-report.component';
import { CreateQueryStatusSuccessComponent } from './equipment/4.8 Create query status/create-query-status-success/create-query-status-success.component';
import { ReportEquipmentQuerySuccessComponent } from './equipment/4.7 Report Equipment query/report-equipment-query-success/report-equipment-query-success.component';
import { ConfirmEmployeeRegistrationComponent } from './Admin/2.1Register Employee/2.1  Register Employee/confirm-employee-registration/confirm-employee-registration.component';
import { CheckEquipmentSuccessfullySavedComponent } from './equipment/4.2 Check equipment/check-equipment-successfully-saved/check-equipment-successfully-saved.component';
import { DeleteOnboarderFailedComponent } from './Admin/2.1Register Employee/2.4 Delete onboarder/delete-onboarder-failed/delete-onboarder-failed.component';



@NgModule({
  declarations: [
    AppComponent,
    AdministratorlandingComponent,
    CreateCourseComponent,
    CourseSuccessdialogueComponent,
    CourseCreationfailureComponent,
    CourseCreationSuccessComponent,
    CreateQuestionComponent,
    ConfirmCreateQuestionComponent,
    QuestionCreationFailureComponent,
    QuestionCreationSuccessComponent,
    CancelQuestionCreationComponent,
    ViewCoursesAdminComponent,
    ViewCourseErrorComponent,
    UpdateCourseComponent,
    CourseCreatedSuccessfullComponent,
    CourseUpdateSuccessfullComponent,
    CourseUpdateFailureComponent,
    ConfirmUpdateCourseComponent,
    DeleteCourseConfirmationComponent,
    CourseDeletionSuccessfulComponent,
    ViewQuestionBankComponent,
    ViewQuestionBankErrorComponent,
    SetQuizComponent,
    SetQuizConfimationComponent,
    SetQuizUnsuccessfulComponent,
    SetQuizSuccessfulComponent,
    LessonOutcomeComponent,
    ComfirmLessonOutcomeCreationComponent,
    LessonoutcomeCreationfailureComponent,
    ViewLessonOutcomeComponent,
    EditLessonOutcomeComponent,
    LessonOutcomeUpdateSuccessfullComponent,
    LessonoutcomeUpdateSuccessfullComponent,
    DeleteLessonoutcomeConfirmationComponent,
    ViewArchivedLessonContentComponent,
    DeleteArchivedLessonContentConfimationComponent,
    DeleteArchivedLessonContentSuccessfullyComponent,
    DeletelessonContentUnsuccessfullComponent,
    ArchivelessonContentComponent,
    ComfirmLessonContentArchiveComponent,
    LessonContentAchirvedSuccefullyComponent,
    LessonUnsuccessfullyArchivedComponent,
    EquipmentLandingPageComponent,
    RegisteronBoarderComponent,
    EditOnboarderComponent,
    OnboarderSuccessfullyEditedComponent,
    ConfirmOnboarderChangesComponent,
    ViewOnboardersComponent,
    ConfirmDeleteOnboarderComponent,
    OnboarderSuccesfullydeletedComponent,
    ConfirmRegisterEmployeeComponent,
    EmployeeRegistrationSuccessComponent,
    RegisterEquipmentComponent,
    ViewEquipmentComponent,
    EquipmentRetrievefailedComponent,
    ViewTradeInStatusComponent,
    TradeInStatusRetrivalFAiledComponent,
    SendEquipmentdueForTradeInComponent,
    ViewpagesComponent,
   
    ValidationUnsuccessfullComponent,
        DescriptionRequiredComponent,
        ResolveQueryComponent,
        EquipmentDescriptionRequiredComponent,
        QuerySuccessfullyCAncelledComponent,
        ViewQueryStatusComponent,
        QueryStatusNotFoundComponent,
        CreateQuaryStatusComponent,
        CreateQueryStatusVAlidationErrorComponent,
        ConfirmCreateStatusComponent,
        UnableToSAveQueryStatusComponent,
        FailedToCreateQueryComponent,
        InvalidDescriptionComponent,
        UpdateEquipmentComponent,
   
        UpdateEquipmentConfirmationComponent,
        UpdateEquipmentVAlidationComponent,
        ViewEquipmentUpdateComponent,
        EquipmentSuccessfyllySavedComponent,
        RegisterEquipmentConfirmComponent,
        DeleteEquipmentComponent,
        ConfirmdeleteEquipmentComponent,
        DeleteEquipmentfailedComponent,
        RegisterEquipmentValidationErrorComponent,
        UnableToSAveEquipmentComponent,
        EquipementSendEquipmentQueryComponent,
        CheckEquipmentComponent,
        CheckEquipmentValidationComponent,
        CheckEquipmentConfirmationComponent,
        PushNotificationComponent,
        SearchEquipmentComponent,
        NosearchCriteriaComponent,
        FailedToRetrieveResultsComponent,
        ViewAssignedEquipmentComponent,
        AssignedEquipmentNotFoundComponent,
        EquipmentUpdateSuccessfullyComponent,
        EquipmentSuccessfullyDeletedComponent,
        SearchQueryStatusComponent,
        SearchQueryCriteriaRequiredComponent,
        SearchQueryStatusValidationUnsuccessfullComponent,
        SendEquipmentforTradeInDEscriptionREquiredComponent,
        SendEquipmentDueForTradeInStatusValidationUnsuccessfullComponent,
        FailedToRetrieveTradeInStatusComponent,
        SendEquipmentDueforTradeinConfirmationComponent,
        UpdateQuetsionBankComponent,
        UpdateQuestionBankConfirmComponent,
        QuestionBAnkSuccessfullyUpdatedComponent,
        UpdateQuestionBankErrorComponent,
        ViewQuestionBankQuestionsComponent,
        DeleteQuestionConfirmComponent,
        QuestionDeletedSuccessfullyComponent,
        QuestionDeleteUnsuccessfullComponent,
        UpdateQuestionComponent,
        ConfirmUpdateQuestionComponent,
        QuestionSuccefullyUpdatedComponent,
        UpdateQuestionErrorComponent,
        CreateAchievementTypeComponent,
        AchievementTypeCreatedSuccessfullComponent,
        UpdateAchievementTypeComponent,
        AchievementTYpeUpdateSuccessfullComponent,
        AchievementTypeupdateUnsuccessfullComponent,
        ViewAchivementTypesComponent,
        DeleteAchievementTypeComponent,
        AchievementTypeDeletionSuccessfullComponent,
        AchievementTypeDeletionUnsuccessfullComponent,
        LessonOutcomeCreationSuccessComponent,
        ConfirmEditLessonOutcomeComponent,
        DeleteLessonoutcomeSuccessfullComponent,
        CreateAchievementTypeConfirmationComponent,
        CreateAchievementTypeUnsuccessfullComponent,
        ConfirmAchievementTypeUpdateComponent,
        EditCourseComponent,
        ConfirmRegistrationComponent,
        DeleteEquipmentConfirmationComponent,
        ReportqueryConfirmationComponent,
        ConfirmCreateCourseComponent,
        DeleteCourseUnsuccessfullComponent,
        QuestionDeletionErrorComponent,
        AchievementTYpeunsuccessfullyCreatedComponent,
        ViewLessonOutcomeVIewErroComponent,
        LessonOutcomeUpdateunsuccessfullComponent,
        LessonOutcomeDeletionunsuccesfullComponent,
        ViewArchivedLessonContentErrorComponent,
        UnArchiveFailedComponent,
        SearchARcivedLessonContentCouldnotFindMatchComponent,
        SearchAchievemenTypeCouldNotFindMatchComponent,
        ViewAchievementTypeErrorComponent,
        GenerateCourseProgressComponent,
        AdminLanding2Component,
        ReportScreenComponent,
        ReportsScreenComponent,
        ViewOnboarderComponent,
        DisplayOnboarderInformationfailedComponent,
        Editonboarder2Component,
        EquipmentAssignedSuccessfullyComponent,
        EquipmentAssignedUnsuccessfullComponent,
        AssignedEquipmentComponent,
        SearchOnboarderFailureComponent,
        OnboarderProgressReportComponent,
        CreateQueryStatusSuccessComponent,
        ReportEquipmentQuerySuccessComponent,
        ConfirmEmployeeRegistrationComponent,
        CheckEquipmentSuccessfullySavedComponent,
        DeleteOnboarderFailedComponent,
       
        
       
  
    
       
    
      
        
    // QuestionCreatedSuccessfulComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatCardModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatDialogModule,
    MatSelectModule,
    MatRadioModule,
    MatTableModule,
    MatSidenavModule,
    MatIconModule,
    MatToolbarModule,
    MatListModule,
    MatDividerModule,
    RouterModule,
    MatCheckboxModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
