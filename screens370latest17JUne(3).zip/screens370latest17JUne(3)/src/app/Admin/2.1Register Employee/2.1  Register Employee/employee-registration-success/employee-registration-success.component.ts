import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-registration-success',
  templateUrl: './employee-registration-success.component.html',
  styleUrls: ['./employee-registration-success.component.css']
})
export class EmployeeRegistrationSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
