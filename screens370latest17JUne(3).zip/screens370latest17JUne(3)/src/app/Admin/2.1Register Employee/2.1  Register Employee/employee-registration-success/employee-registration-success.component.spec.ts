import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeRegistrationSuccessComponent } from './employee-registration-success.component';

describe('EmployeeRegistrationSuccessComponent', () => {
  let component: EmployeeRegistrationSuccessComponent;
  let fixture: ComponentFixture<EmployeeRegistrationSuccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeRegistrationSuccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeRegistrationSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
