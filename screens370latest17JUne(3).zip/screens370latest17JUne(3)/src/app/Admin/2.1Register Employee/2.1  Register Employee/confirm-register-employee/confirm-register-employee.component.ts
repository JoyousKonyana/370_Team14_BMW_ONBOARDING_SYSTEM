import { EmployeeRegistrationSuccessComponent } from './../employee-registration-success/employee-registration-success.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-confirm-register-employee',
  templateUrl: './confirm-register-employee.component.html',
  styleUrls: ['./confirm-register-employee.component.css']
})
export class ConfirmRegisterEmployeeComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialogEmployeeREgistrationSuccessfull() {
    const dialogRef = this.dialog.open(EmployeeRegistrationSuccessComponent);

    dialogRef.afterClosed().subscribe(result => {
    
    });
}

}
