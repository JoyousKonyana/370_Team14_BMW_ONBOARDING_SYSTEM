import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmRegisterEmployeeComponent } from './confirm-register-employee.component';

describe('ConfirmRegisterEmployeeComponent', () => {
  let component: ConfirmRegisterEmployeeComponent;
  let fixture: ComponentFixture<ConfirmRegisterEmployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmRegisterEmployeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmRegisterEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
