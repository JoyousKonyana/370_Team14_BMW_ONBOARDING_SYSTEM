import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisteronBoarderComponent } from './registeron-boarder.component';

describe('RegisteronBoarderComponent', () => {
  let component: RegisteronBoarderComponent;
  let fixture: ComponentFixture<RegisteronBoarderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisteronBoarderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisteronBoarderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
