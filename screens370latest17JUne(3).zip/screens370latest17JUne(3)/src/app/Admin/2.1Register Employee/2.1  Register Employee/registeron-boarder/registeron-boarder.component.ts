import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmRegisterEmployeeComponent } from '../confirm-register-employee/confirm-register-employee.component';
@Component({
  selector: 'app-registeron-boarder',
  templateUrl: './registeron-boarder.component.html',
  styleUrls: ['./registeron-boarder.component.css']
})
export class RegisteronBoarderComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }
  openDialogConfirmRegisterOnboarder() {
    const dialogRef = this.dialog.open(ConfirmRegisterEmployeeComponent);

    dialogRef.afterClosed().subscribe(result => {
    
    });
}
}
