import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-employee-registration',
  templateUrl: './confirm-employee-registration.component.html',
  styleUrls: ['./confirm-employee-registration.component.css']
})
export class ConfirmEmployeeRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
