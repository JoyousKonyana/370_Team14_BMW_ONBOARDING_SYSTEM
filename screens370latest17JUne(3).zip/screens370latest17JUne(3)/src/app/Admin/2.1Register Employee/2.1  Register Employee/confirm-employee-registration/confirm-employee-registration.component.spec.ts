import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmEmployeeRegistrationComponent } from './confirm-employee-registration.component';

describe('ConfirmEmployeeRegistrationComponent', () => {
  let component: ConfirmEmployeeRegistrationComponent;
  let fixture: ComponentFixture<ConfirmEmployeeRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmEmployeeRegistrationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmEmployeeRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
